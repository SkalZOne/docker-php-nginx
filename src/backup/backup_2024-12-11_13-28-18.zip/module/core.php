<?
namespace classes;

use PDO;

class core{
	
	//конект к базе данных админ. панели
	public static function connectDB(){
		global $DBH;
		if(!$DBH){
			$host = 'localhost';
			$dbname = 'infoaqtl_adm';
			$user = 'infoaqtl_adm';
			$pass = '0xFlK&sQ!csp';
			$DBH = new PDO("mysql:host=$host;dbname=$dbname;charset=UTF8", $user, $pass, [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ]);
			// echo '~con~';
			return $DBH;
		}else{
			return $DBH;
		}
	}
	
	//конект к сторонней базе данных
	public static function other_connectDB($admId, $arr = false){
		global $ODBH;
		if (!isset($ODBH[$admId]) || !$ODBH[$admId] instanceof PDO) {
			if( !is_array($arr) ){
				$arr = self::getContentById($admId, true);
			}
			$host = $arr['adm_server'];
			$dbname = $arr['adm_name'];
			$user = $arr['adm_user'];
			$pass = $arr['adm_password'];
			$ODBH[$admId] = new PDO("mysql:host=$host;dbname=$dbname;charset=UTF8", $user, $pass, [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ]);
			return $ODBH[$admId];
		}else{
			return $ODBH[$admId];
		}
	}
	
	
	
	
	
	
	public static function test(){
		return 'GO51'; 
	}
}
?>