<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>МедПортал</title>
    <link rel="stylesheet" href="https://layout.rmp-portal.ru/site/css/style.css">
    <link rel="stylesheet" href="https://layout.rmp-portal.ru/site/css/tpl_style.css">
    <link rel="stylesheet" href="https://layout.rmp-portal.ru/site/css/custom_classes.css">
    <link rel="stylesheet" href="https://layout.rmp-portal.ru/site/css/owl.carousel.min.css">

    <script src="https://layout.rmp-portal.ru/site/lib/jquery/jquery.js"></script>

    <link href="https://layout.rmp-portal.ru/site/lib/bootstrap/style.css" rel="stylesheet">
    <script src="https://layout.rmp-portal.ru/site/lib/bootstrap/script.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <script src="https://layout.rmp-portal.ru/site/js/scripts.js"></script>
    <script src="https://layout.rmp-portal.ru/site/js/owl.carousel.min.js"></script>

    <link
        href="https://fonts.googleapis.com/css2?family=Literata:ital,opsz,wght@0,7..72,200;0,7..72,300;0,7..72,400;0,7..72,500;0,7..72,600;0,7..72,700;0,7..72,800;0,7..72,900;1,7..72,200;1,7..72,300;1,7..72,400;1,7..72,500;1,7..72,600;1,7..72,700;1,7..72,800;1,7..72,900&family=Montserrat:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet"
    >
	
</head>
<body>
<br/>
<br/>
<br/>
    <!-- main-block -->
    <div class="main-slider-top">
        <div class="main-block-slider owl-carousel">
            <div class="container d-flex flex-column p-5 def-border-rad align-items-start" style="background-color: #ffa230;">
                <h1 class="fw-bold text-white col-6">Укрепляем здоровье с витаминами Dr. Verdi</h1>
                <div class="mt-2">Новейшие технологии производства позволяют достичь оптимального баланса ингредиентов, необходимых для здоровья организма.</div>
                <div class="mt-3 button">Забрать за 15 минут</div>
            </div>
            <div class="container d-flex flex-column p-5 def-border-rad align-items-start" style="background-color: #ffa230;">
                <h1 class="fw-bold text-white col-6">Укрепляем здоровье с витаминами Dr. Verdi</h1>
                <div class="mt-2">Новейшие технологии производства позволяют достичь оптимального баланса ингредиентов, необходимых для здоровья организма.</div>
                <div class="mt-3 button">Забрать за 15 минут</div>
            </div>
        </div>
        <script>
            $(window).on('load', function () {
                $('.main-block-slider.owl-carousel').owlCarousel({
                    margin: 0,
                    nav: false,
                    dots: false,
                    loop: false,
                    responsive: {
                        0: {
                            items: 1
                        }
                    }
                });
            })
        </script>
    </div>
    <!-- main-block -->

    <!-- main-content -->
    <div class="main-container d-flex">
            <div class="main-content def-shadow p-5">
                <!-- Хлебные крошки -->
                <div class="breadcrumbs">
                    <div class="fs-mini">Главная</div>
                    <div class="chevron-right">
                        <img src="https://layout.rmp-portal.ru/site/img/chevron-right.svg" alt="chevron-right">
                    </div>
                    <div class="fs-mini">О нас</div>
                    <div class="chevron-right">
                        <img src="https://layout.rmp-portal.ru/site/img/chevron-right.svg" alt="chevron-right">
                    </div>
                    <div class="fs-mini">Сведения об организации</div>
                </div>
                <!-- Хлебные крошки -->

                <!-- Основной контент -->
                <div class="main-content-block mt-5">
					<?=$propVal['1']['pr_value']?>
                </div>
                <div class="main-content-block-carousel">
                    <div class="block-main-carousel-title">
                        <div class="tittle-doctors">Врачи</div>
                        <div class="title-all-doctors">
                            <a class="all-doctors">Все врачи</a>
                            <div class="all-doctors-chevron">
                                <img class="title-all-doctors-chevron" src="https://layout.rmp-portal.ru/site/img/chevron-right-blue.svg" alt="chevron-right">
                            </div>
                        </div>
                    </div>
                    <div class="employees owl-carousel">
                        <div class="employee img-hover-slider def-border-rad" style="background-image: url(https://layout.rmp-portal.ru/site/img/employee1.jpg);">
                            <div class="employee-logo zindex-relative">
                                <img class="employee-logo-img" src="https://layout.rmp-portal.ru/site/img/employee-logo.png">
                            </div>
                            <div class="employee-info zindex-relative">
                                <div class="employee-info-name">
                                    Громов Валерий Леонидович
                                </div>
                                <div class="employee-info-speciality">
                                    Оториноларинголог
                                </div>
                                <button class="employee-info-button btn-main">
                                    Записаться на прием
                                </button>
                            </div>
                        </div>
                        <div class="employee img-hover-slider def-border-rad" style="background-image: url(https://layout.rmp-portal.ru/site/img/employee2.jpg);">
                            <div class="employee-logo zindex-relative">
                                <img class="employee-logo-img" src="https://layout.rmp-portal.ru/site/img/employee-logo.png">
                            </div>
                            <div class="employee-info zindex-relative">
                                <div class="employee-info-name">
                                    Волков Александр Аркадьевич
                                </div>
                                <div class="employee-info-speciality">
                                    Окулист (офтальмолог)
                                </div>
                                <button class="employee-info-button btn-main">
                                    Записаться на прием
                                </button>
                            </div>
                        </div>
                        <div class="employee img-hover-slider def-border-rad" style="background-image: url(https://layout.rmp-portal.ru/site/img/employee3.jpg);">
                            <div class="employee-logo zindex-relative">
                                <img class="employee-logo-img" src="https://layout.rmp-portal.ru/site/img/employee-logo.png">
                            </div>
                            <div class="employee-info zindex-relative">
                                <div class="employee-info-name">
                                    Лебедев Константин Вячеславович
                                </div>
                                <div class="employee-info-speciality">
                                    Невропатолог (невролог)
                                </div>
                                <button class="employee-info-button btn-main">
                                    Записаться на прием
                                </button>
                            </div>
                        </div>
                        <div class="employee img-hover-slider def-border-rad" style="background-image: url(https://layout.rmp-portal.ru/site/img/employee4.jpg);">
                            <div class="employee-logo zindex-relative">
                                <img class="employee-logo-img" src="https://layout.rmp-portal.ru/site/img/employee-logo.png">
                            </div>
                            <div class="employee-info zindex-relative">
                                <div class="employee-info-name">
                                    Воронцова Татьяна Борисовна
                                </div>
                                <div class="employee-info-speciality">
                                    Гинеколог
                                </div>
                                <button class="employee-info-button btn-main">
                                    Записаться на прием
                                </button>
                            </div>
                        </div>
                        <div class="employee img-hover-slider def-border-rad" style="background-image: url(https://layout.rmp-portal.ru/site/img/employee5.jpg);">
                            <div class="employee-logo zindex-relative">
                                <img class="employee-logo-img" src="https://layout.rmp-portal.ru/site/img/employee-logo.png">
                            </div>
                            <div class="employee-info zindex-relative">
                                <div class="employee-info-name">
                                    Мельникова Надежда Андреевна
                                </div>
                                <div class="employee-info-speciality">
                                    Кардиолог
                                </div>
                                <button class="employee-info-button btn-main">
                                    Записаться на прием
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        const employees = document.querySelectorAll(".employee");

                        employees.forEach(employee => {
                            employee.addEventListener("mouseenter", function() {
                                employees.forEach(emp => emp.classList.remove("active"));
                                employee.classList.add("active");
                            });

                            employee.addEventListener("mouseleave", function() {
                                employee.classList.remove("active");
                            });
                        });
                    });
                </script>
                <script>
                    $(window).on('load', function () {
                        $('.employees.owl-carousel').owlCarousel({
                            margin: 20,
                            nav: true,
                            dots: false,
                            loop: true,
                            responsive: {
                                0: {
                                    items: 4.1
                                }
                            }
                        });
                    })
                </script>
                <div class="main-content-block mt-5">
                    <?=$propVal['2']['pr_value']?>
                </div>
                <div class="main-content-block-choice">
                    <h3 class="block-choice-title">Как выбрать терапевта?</h3>
                    <p>Посещение терапевта в семейной клинике «МЕДЭП» в Новых Ватутинках гарантирует вам получение качественной медицинской помощи экспертного уровня, так как все специалисты проходят своевременное обучение и повышение квалификации по своему профилю, участвуют консилиумах между филиалами, а также имеют возможность получить консультацию у ведущих специалистов Москвы и России (профессоров, докторов и кандидатов медицинских наук).</p>
                </div>
                <div class="main-content-block-ad-sale d-flex my-5">
                    <a href="#">
                        <img class="banner-analysis" src="https://layout.rmp-portal.ru/site/img/banner-analisys.png">
                        <div class="advertisement advertisement-main">
                            Реклама
                            <div class="advertisement-tooltip">
                                АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                            </div>
                        </div>
                    </a>
                </div>
                <div class="main-content-block mt-5">
                    <?=$propVal['2']['pr_value']?>
                </div>
                <div class="main-content-block-ad-therapy">
                    <a href="#" class="banner-therapy">
                        <img class="banner-therapy" src="https://layout.rmp-portal.ru/site/img/banner-therapy.png">
                        <div class="advertisement advertisement-main">
                            Реклама
                            <div class="advertisement-tooltip">
                                АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                            </div>
                        </div>
                    </a>
                    <a href="#" class="banner-therapy">
                        <img class="banner-therapy" src="https://layout.rmp-portal.ru/site/img/banner-therapy.png">
                        <div class="advertisement advertisement-main">
                            Реклама
                            <div class="advertisement-tooltip">
                                АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                            </div>
                        </div>
                    </a>
                </div>
                <div class="main-content-block mt-5">
                    <?=$propVal['3']['pr_value']?>
                </div>
                <div class="main-content-block-ad-middle d-flex">
                    <a href="#" class="banner-sail">
                        <div class="banner-container">
                            <img class="banner-sail" src="https://layout.rmp-portal.ru/site/img/banner-sail-first.png">
                            <div class="advertisement advertisement-main">
                                Реклама
                                <div class="advertisement-tooltip">
                                    АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="#" class="banner-sail">
                        <div class="banner-container">
                            <img class="banner-sail" src="https://layout.rmp-portal.ru/site/img/banner-sail-second.png">
                            <div class="advertisement advertisement-main">
                                Реклама
                                <div class="advertisement-tooltip">
                                    АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                                </div>
                            </div>
                        </div>
                    </a>
                </div> 
				<div class="main-content-block mt-5">
                    <?=$propVal['4']['pr_value']?>
                </div> 
               

                <!-- запись на прием -->
                <div class="main-content-block-appointment">
                    <div class="block-appointment-logo zindex-relative">
                        <img class="appointment-logo-img" src="https://layout.rmp-portal.ru/site/img/employee-logo.png">
                    </div>
                    <div class="block-appointment-container">
                        <div class="appointment-title">
                            Записаться на прием к терапевту
                        </div>
                        <div class="appointment-text">
                            Профессиональная помощь в диагностике и профилактике заболеваний
                        </div>
                        <div class="appointment-button d-flex">
                            <button class="appointment-btn-white">Выбрать другой медцентр</button>
                            <button class="appointment-btn-main btn-main">Записаться на прием</button>
                        </div>
                    </div>
                </div>
                <!-- запись на прием -->

                <div class="main-content-block-share mt-5">
                    <div class="block-share-title mb-2">Поделиться статьей</div>
                    <div class="block-share-container d-flex">
                        <a href="" class="share-btn def-border-rad">
                            <img src="https://layout.rmp-portal.ru/site/img/share-vk.png" alt="">
                        </a>
                        <a href="" class="share-btn def-border-rad">
                            <img src="https://layout.rmp-portal.ru/site/img/share-whatsapp.png" alt="">
                        </a>
                        <a href="" class="share-btn def-border-rad">
                            <img src="https://layout.rmp-portal.ru/site/img/share-tg.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="main-content-block-promotions mt-5">
                    <div class="block-promotions-title">
                        <div class="tittle-stock">
                            Акции
                        </div>
                        <div class="title-all-stock">
                            <a class="all-stock">
                                Все акции
                            </a>
                            <div class="all-stock-chevron">
                                <img class="title-all-stock-chevron" src="https://layout.rmp-portal.ru/site/img/chevron-right-blue.svg" alt="chevron-right">
                            </div>
                        </div>
                    </div>
                    <div class="promotions owl-carousel">
                        <div class="promotion">
                            <img src="https://layout.rmp-portal.ru/site/img/promotion-item-first.png" alt="" class="mb-2">
                            <div class="advertisement advertisement-main">
                                Реклама
                                <div class="advertisement-tooltip">
                                    АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                                </div>
                            </div>
                            <div class="promotion-text">Скидка 15%</div>
                        </div>
                        <div class="promotion">
                            <img src="https://layout.rmp-portal.ru/site/img/promotion-item-second.png" alt="" class="mb-2">
                            <div class="advertisement advertisement-main">
                                Реклама
                                <div class="advertisement-tooltip">
                                    АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                                </div>
                            </div>
                            <div class="promotion-text">Скидка 25%</div>
                        </div>
                        <div class="promotion">
                            <img src="https://layout.rmp-portal.ru/site/img/promotion-item-first.png" alt="" class="mb-2">
                            <div class="advertisement advertisement-main">
                                Реклама
                                <div class="advertisement-tooltip">
                                    АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                                </div>
                            </div>
                            <div class="promotion-text">Скидка 35%</div>
                        </div>
                        <div class="promotion">
                            <img src="https://layout.rmp-portal.ru/site/img/promotion-item-second.png" alt="" class="mb-2">
                            <div class="advertisement advertisement-main">
                                Реклама
                                <div class="advertisement-tooltip">
                                    АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                                </div>
                            </div>
                            <div class="promotion-text">Скидка 45%</div>
                        </div>
                    </div>
                </div>
                <script>
                    $(window).on('load', function () {
                        $('.promotions.owl-carousel').owlCarousel({
                            margin: 30,
                            nav: true,
                            dots: false,
                            loop: true,
                            responsive: {
                                0: {
                                    items: 3.4
                                }
                            }
                        });
                    })
                </script>
                <div class="main-content-block-product">
                    <div class="block-product-title">
                        <div class="product-btn-container">
                            <div class="product-btn active">
                                Лучшие предложения
                            </div>
                            <div class="product-btn">
                                Популярные товары
                            </div>
                            <div class="product-btn">
                                Вместе выгоднее!
                            </div>
                            <div class="product-btn">
                                -20% при покупке 2-х
                            </div>
                            <div class="product-btn">
                                -30% на 2-ую упаковку
                            </div>
                            <div class="product-btn">
                                К школе готов
                            </div>
                            <div class="product-btn">
                                Новинки
                            </div>
                        </div>
                        <div class="product-catalog">
                            <a class="catalog">
                                Каталог
                            </a>
                            <div class="catalog-chevron">
                                <img class="title-all-stock-chevron" src="https://layout.rmp-portal.ru/site/img/chevron-right-blue.svg" alt="chevron-right">
                            </div>
                        </div>
                    </div>
                    <div class="block-products-carousel owl-carousel">
                        <div class="product-container">
                                <div class="product-img-list" style="background-image: url(https://layout.rmp-portal.ru/site/img/product-1.png)">
                                    <div class="product-heart">
                                        <img src="https://layout.rmp-portal.ru/site/img/product-heart.svg">
                                    </div>
                                    <div class="product-list">
                                        <div class="point point-pink">
                                            Рекомендуем
                                        </div>
                                        <div class="point point-violet">
                                            +5 бонусов
                                        </div>
                                        <div class="point point-blue">
                                            Товар дня
                                        </div>
                                    </div>
                                </div>
                                <div class="product-name">
                                    Калия йодид таблетки 0,2 мг 100 шт
                                </div>
                                <div class="product-price">
                                    <div class="price">
                                        504 ₽
                                    </div>
                                    <div class="old-price">
                                        631 ₽
                                    </div>
                                </div>
                                <button class="product-buy btn-main">
                                    Купить
                                </button>
                            </div>
                        <div class="product-container">
                            <div class="product-img-list" style="background-image: url(https://layout.rmp-portal.ru/site/img/product-2.png)">
                                <div class="product-heart">
                                    <img src="https://layout.rmp-portal.ru/site/img/product-heart.svg">
                                </div>
                                <div class="product-list">
                                    <div class="point point-orange">
                                        Хит продаж
                                    </div>
                                    <div class="point point-blue">
                                        Товар дня
                                    </div>
                                </div>
                            </div>
                            <div class="product-name">
                                Цетиризин Реневал капли для приема внутрь 10 мг/мл 10 мл 1 шт
                            </div>
                            <div class="product-price">
                                <div class="price">
                                    1300 ₽
                                </div>
                                <div class="old-price">
                                    2000 ₽
                                </div>
                            </div>
                            <button class="product-buy btn-main">
                                Купить
                            </button>
                        </div>
                        <div class="product-container">
                            <div class="product-img-list" style="background-image: url(https://layout.rmp-portal.ru/site/img/product-3.png)">
                                <div class="product-heart">
                                    <img src="https://layout.rmp-portal.ru/site/img/product-heart.svg">
                                </div>
                                <div class="product-list">
                                    <div class="point point-violet">
                                        +5 бонусов
                                    </div>
                                    <div class="point point-blue">
                                        Товар дня
                                    </div>
                                </div>
                            </div>
                            <div class="product-name">
                                Диметинден-Акрихин гель для наружного применения 0,1 % 30 г 1 шт
                            </div>
                            <div class="product-price">
                                <div class="price">
                                    120 ₽
                                </div>
                                <div class="old-price">

                                </div>
                            </div>
                            <button class="product-buy btn-main">
                                Купить
                            </button>
                        </div>
                        <div class="product-container">
                            <div class="product-img-list" style="background-image: url(https://layout.rmp-portal.ru/site/img/product-1.png)">
                                <div class="product-heart">
                                    <img src="https://layout.rmp-portal.ru/site/img/product-heart.svg">
                                </div>
                                <div class="product-list">
                                    <div class="point point-orange">
                                        Хит продаж
                                    </div>
                                    <div class="point point-violet">
                                        +5 бонусов
                                    </div>
                                    <div class="point point-pink">
                                        Рекомендуем
                                    </div>
                                </div>
                            </div>
                            <div class="product-name">
                                Милдронат капсулы 250 мг <br> 40 шт
                            </div>
                            <div class="product-price">
                                <div class="price">
                                    504 ₽
                                </div>
                                <div class="old-price">
                                    631 ₽
                                </div>
                            </div>
                            <button class="product-buy btn-main">
                                Купить
                            </button>
                        </div>
                        <div class="product-container">
                            <div class="product-img-list" style="background-image: url(https://layout.rmp-portal.ru/site/img/product-1.png)">
                                <div class="product-heart">
                                    <img src="https://layout.rmp-portal.ru/site/img/product-heart.svg">
                                </div>
                                <div class="product-list">
                                    <div class="point point-pink">
                                        Рекомендуем
                                    </div>
                                    <div class="point point-violet">
                                        +5 бонусов
                                    </div>
                                    <div class="point point-blue">
                                        Товар дня
                                    </div>
                                </div>
                            </div>
                            <div class="product-name">
                                Калия йодид таблетки 0,2 мг 100 шт
                            </div>
                            <div class="product-price">
                                <div class="price">
                                    504 ₽
                                </div>
                                <div class="old-price">
                                    631 ₽
                                </div>
                            </div>
                            <button class="product-buy btn-main">
                                Купить
                            </button>
                        </div>
                        <div class="product-container">
                            <div class="product-img-list" style="background-image: url(https://layout.rmp-portal.ru/site/img/product-1.png)">
                                <div class="product-heart">
                                    <img src="https://layout.rmp-portal.ru/site/img/product-heart.svg">
                                </div>
                                <div class="product-list">
                                    <div class="point point-pink">
                                        Рекомендуем
                                    </div>
                                    <div class="point point-violet">
                                        +5 бонусов
                                    </div>
                                    <div class="point point-blue">
                                        Товар дня
                                    </div>
                                </div>
                            </div>
                            <div class="product-name">
                                Калия йодид таблетки 0,2 мг 100 шт
                            </div>
                            <div class="product-price">
                                <div class="price">
                                    504 ₽
                                </div>
                                <div class="old-price">
                                    631 ₽
                                </div>
                            </div>
                            <button class="product-buy btn-main">
                                Купить
                            </button>
                        </div>
                    </div>
                </div>
                <script>
                    $(window).on('load', function () {
                        $('.block-products-carousel.owl-carousel').owlCarousel({
                            margin: 20,
                            nav: true,
                            dots: false,
                            loop: true,
                            responsive: {
                                0: {
                                    items: 4.3
                                }
                            }
                        });
                    })
                </script>
                <div class="main-content-block-events">
                    <div class="block-events-title">
                        <div class="tittle-events">
                            Мероприятия
                        </div>
                        <div class="title-all-events">
                            <a class="all-events">
                                Все Мероприятия
                            </a>
                            <div class="all-events-chevron">
                                <img class="title-all-events-chevron" src="https://layout.rmp-portal.ru/site/img/chevron-right-blue.svg" alt="chevron-right">
                            </div>
                        </div>
                    </div>
                    <div class="block-events-carousel owl-carousel">
                        <div class="events-container">
                            <div class="events-img-list">
                                <img src="https://layout.rmp-portal.ru/site/img/events-1.png">
                                <div class="events-list">
                                    <div class="point point-gray">
                                        Бесплатно
                                    </div>
                                    <div class="point point-blue">
                                        20 ноября
                                    </div>
                                    <div class="point point-orange">
                                        25 ноября
                                    </div>
                                </div>
                            </div>
                            <div class="events-name">
                                Здоровый сон: секреты <br> крепкого сна
                            </div>
                            <div class="events-type">
                                Вебинар
                            </div>
                            <div class="events-button btn-main">
                                Подробнее
                            </div>
                        </div>
                        <div class="events-container">
                            <div class="events-img-list">
                                <img src="https://layout.rmp-portal.ru/site/img/events-2.png">
                                <div class="events-list">
                                    <div class="point point-gray">
                                        20 000 ₽
                                    </div>
                                    <div class="point point-violet">
                                        29 ноября
                                    </div>
                                </div>
                            </div>
                            <div class="events-name">
                                Питайся правильно, живи дольше!
                            </div>
                            <div class="events-type">
                                Марафон
                            </div>
                            <div class="events-button btn-main">
                                Подробнее
                            </div>
                        </div>
                        <div class="events-container">
                            <div class="events-img-list">
                                <img src="https://layout.rmp-portal.ru/site/img/events-3.png">
                                <div class="events-list">
                                    <div class="point point-gray">
                                        Бесплатно
                                    </div>
                                    <div class="point point-blue">
                                        20 ноября
                                    </div>
                                </div>
                            </div>
                            <div class="events-name">
                                Городской забег
                            </div>
                            <div class="events-type">
                                Марафон
                            </div>
                            <div class="events-button btn-main">
                                Подробнее
                            </div>
                        </div>
                        <div class="events-container">
                            <div class="events-img-list">
                                <img src="https://layout.rmp-portal.ru/site/img/events-4.png">
                                <div class="events-list">
                                    <div class="point point-gray">
                                        5 000 ₽
                                    </div>
                                    <div class="point point-blue">
                                        20 ноября
                                    </div>
                                    <div class="point point-orange">
                                        25 ноября
                                    </div>
                                </div>
                            </div>
                            <div class="events-name">
                                Витамины для энергии и бодрости
                            </div>
                            <div class="events-type">
                                Вебинар
                            </div>
                            <div class="events-button btn-main">
                                Подробнее
                            </div>
                        </div>
                        <div class="events-container">
                            <div class="events-img-list">
                                <img src="https://layout.rmp-portal.ru/site/img/events-4.png">
                                <div class="events-list">
                                    <div class="point point-gray">
                                        5 000 ₽
                                    </div>
                                    <div class="point point-blue">
                                        20 ноября
                                    </div>
                                    <div class="point point-orange">
                                        25 ноября
                                    </div>
                                </div>
                            </div>
                            <div class="events-name">
                                Витамины для энергии и бодрости
                            </div>
                            <div class="events-type">
                                Вебинар
                            </div>
                            <div class="events-button btn-main">
                                Подробнее
                            </div>
                        </div>
                        <div class="events-container">
                            <div class="events-img-list">
                                <img src="https://layout.rmp-portal.ru/site/img/events-4.png">
                                <div class="events-list">
                                    <div class="point point-gray">
                                        5 000 ₽
                                    </div>
                                    <div class="point point-blue">
                                        20 ноября
                                    </div>
                                    <div class="point point-orange">
                                        25 ноября
                                    </div>
                                </div>
                            </div>
                            <div class="events-name">
                                Витамины для энергии и бодрости
                            </div>
                            <div class="events-type">
                                Вебинар
                            </div>
                            <div class="events-button btn-main">
                                Подробнее
                            </div>
                        </div>
                        <div class="events-container">
                            <div class="events-img-list">
                                <img src="https://layout.rmp-portal.ru/site/img/events-4.png">
                                <div class="events-list">
                                    <div class="point point-gray">
                                        5 000 ₽
                                    </div>
                                    <div class="point point-blue">
                                        20 ноября
                                    </div>
                                    <div class="point point-orange">
                                        25 ноября
                                    </div>
                                </div>
                            </div>
                            <div class="events-name">
                                Витамины для энергии и бодрости
                            </div>
                            <div class="events-type">
                                Вебинар
                            </div>
                            <div class="events-button btn-main">
                                Подробнее
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    $(window).on('load', function () {
                        $('.block-events-carousel.owl-carousel').owlCarousel({
                            margin: 20,
                            nav: true,
                            dots: false,
                            loop: true,
                            responsive: {
                                0: {
                                    items: 4
                                }
                            }
                        });
                    })
                </script>
                <!-- Основной контент -->
            </div>
            <div class="sidebar-container">
                <div class="side-block-address">
                    <div class="block-address-img-logo">
                        <img src="https://layout.rmp-portal.ru/site/img/address-img.jpg" alt="address">
                        <div class="address-logo">
                            <img src="https://layout.rmp-portal.ru/site/img/employee-logo.png" alt="logo">
                        </div>
                    </div>
                    <div class="block-address-title">
                        Медицинский центр
                        «МОСМЕДПРОФ»
                    </div>
                    <div class="block-address-container">
                        <div class="address-svg">
                            <img src="https://layout.rmp-portal.ru/site/img/address-svg-1.png" alt="svg">
                            Открыто до 21:00
                        </div>
                        <div class="address-svg">
                            <img src="https://layout.rmp-portal.ru/site/img/address-svg-2.png" alt="svg">
                            ул. Школьная, д. 11/3
                        </div>
                        <div class="address-svg">
                            <img src="https://layout.rmp-portal.ru/site/img/address-svg-3.png" alt="svg">
                            +7 (000) 000-00-00
                        </div>
                    </div>
                    <button class="block-address-button btn-main">
                        Записаться на прием
                    </button>
                </div>
                <div class="side-block-banner">
                    <a href="#">
                        <img src="https://layout.rmp-portal.ru/site/img/side-banner-1.png">
                        <div class="advertisement advertisement-main">
                            Реклама
                            <div class="advertisement-tooltip">
                                АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                            </div>
                        </div>
                    </a>
                </div>
                <div class="side-block-medication">
                    <div class="block-medication-title">
                        Лекарственные препараты
                    </div>
                    <div class="block-medication-container">
                        <img src="https://layout.rmp-portal.ru/site/img/medication-1.png" alt="">
                        <div class="medication-text">
                            Противовирусные средства
                        </div>
                    </div>
                    <div class="block-medication-container">
                        <img src="https://layout.rmp-portal.ru/site/img/medication-2.png" alt="">
                        <div class="medication-text">
                            От насморка
                        </div>
                    </div>
                    <div class="block-medication-container">
                        <img src="https://layout.rmp-portal.ru/site/img/medication-3.png" alt="">
                        <div class="medication-text">
                            Лечение простуды
                        </div>
                    </div>
                    <div class="block-medication-container">
                        <img src="https://layout.rmp-portal.ru/site/img/medication-4.png" alt="">
                        <div class="medication-text">
                            От повышенного давления
                        </div>
                    </div>
                    <div class="block-medication-container">
                        <img src="https://layout.rmp-portal.ru/site/img/medication-5.png" alt="">
                        <div class="medication-text">
                            От пониженного давления
                        </div>
                    </div>
                    <div class="block-medication-container">
                        <img src="https://layout.rmp-portal.ru/site/img/medication-6.png" alt="">
                        <div class="medication-text">
                            Лечения аллергии
                        </div>
                    </div>
                    <div class="block-medication-container">
                        <img src="https://layout.rmp-portal.ru/site/img/medication-7.png" alt="">
                        <div class="medication-text">
                            От изжоги
                        </div>
                    </div>
                    <div class="block-medication-container">
                        <img src="https://layout.rmp-portal.ru/site/img/medication-8.png" alt="">
                        <div class="medication-text">
                            Противовирусные средства
                        </div>
                    </div>

                </div>
                <div class="side-block-banner-therapy">
                    <div class="banner-therapy-img">
                        <img src="https://layout.rmp-portal.ru/site/img/side-banner-therapy.png">
                    </div>
                    <div class="banner-therapy-button btn-main">
                        Записаться
                    </div>
                </div>
                <div class="side-block-banner-sail">
                    <a class="side-banner-sail">
                        <img src="https://layout.rmp-portal.ru/site/img/side-banner-sail.png" alt="">
                        <div class="advertisement advertisement-main">
                            Реклама
                            <div class="advertisement-tooltip">
                                АПТЕКА, ИНН 777777777777, ЕРИД Rghadvggndkjdbdbdb
                            </div>
                        </div>
                    </a>
                </div>
                <div class="side-block-news">
                    <div class="block-news-tittle">
                        Последние новости
                    </div>
                    <div class="block-news-container">
                        <div class="news-container">
                            <img src="https://layout.rmp-portal.ru/site/img/side-news-1.png">
                            <a class="news-tittle">
                                ЦРПТ объяснил аптекам, что делать с некорректными кодами маркировки БАД.
                            </a>
                            <a class="news-date">
                                25 сентября 2024
                            </a>
                        </div>
                        <div class="news-container">
                            <img src="https://layout.rmp-portal.ru/site/img/side-news-1.png">
                            <a class="news-tittle">
                                ЦРПТ объяснил аптекам, что делать с некорректными кодами маркировки БАД.
                            </a>
                            <a class="news-date">
                                25 сентября 2024
                            </a>
                        </div>
                        <div class="news-container">
                            <img src="https://layout.rmp-portal.ru/site/img/side-news-1.png">
                            <a class="news-tittle">
                                ЦРПТ объяснил аптекам, что делать с некорректными кодами маркировки БАД.
                            </a>
                            <a class="news-date">
                                25 сентября 2024
                            </a>
                        </div>
                    </div>
                    <div class="block-news-button btn-main">
                        Смотреть все
                    </div>
                </div>
                <div class="side-block-score">
                    <div class="block-score-tittle">
                        Оцените наш сайт
                    </div>
                    <div class="score-container">
                        <div class="block-score">
                            <p>Отлично - <span class="score-number">250</span></p>
                            <div class="score-progress score-blue" style="width: 85%;"></div>
                            <div class="score">
                                85%
                            </div>
                        </div>
                        <div class="block-score">
                            <p>Хорошо - <span class="score-number">350</span></p>
                            <div class="score-progress score-blue-light" style="width: 56%;"></div>
                            <div class="score">
                                56%
                            </div>
                        </div>
                        <div class="block-score">
                            <p>Ужасно - <span class="score-number">200</span></p>
                            <div class="score-progress score-red" style="width: 45%;"></div>
                            <div class="score">
                                45%
                            </div>
                        </div>
                        <div class="block-score">
                            <p>Плохо - <span class="score-number">199</span></p>
                            <div class="score-progress score-orange" style="width: 35%;"></div>
                            <div class="score">
                                35%
                            </div>
                        </div>
                    </div>
                    <div class="block-score-quant">
                        Проглосовали 979 человек
                    </div>
                </div>
                <div class="side-block-doctor">
                    <div class="block-doctor-img-logo-text">
                        <img class="side-doctor" src="https://layout.rmp-portal.ru/site/img/side-doctor.png">
                        <div class="doctor-logo">
                            <img src="https://layout.rmp-portal.ru/site/img/employee-logo.png" alt="logo">
                        </div>
                        <div class="doctor-info-text zindex-relative">
                            <div class="doctor-name">
                                Ворнцова Татьяна Борисовна
                            </div>
                            <div class="doctor-speciality">
                                Гинеколог
                            </div>
                        </div>
                    </div>
                    <button class="block-doctor-button btn-main">
                        Записаться
                    </button>
                </div>
            </div>
    </div>
    <div class="main-content-bottom-subscribe">
        <div class="subscribe-text">
            Подпишись, чтобы не пропустить следующие новости и акции
        </div>
        <div class="d-flex" style="gap: 5px;">
            <label for="email"></label>
            <input type="email" id="email" name="email" placeholder="Ваш email">
            <button class="subscribe-btn btn-main">
                Подписаться
            </button>
        </div>
    </div>
	
</body>
</html>