$(document).ready(function(){

    // Закрытие модального окна при клике на крестик
    $('.adm-modal-exit').click(function(){
        closeModal();
    });

    // Закрытие модального окна при клике на неактивную область
    $('.adm-modal').click(function() {
        if( !$(event.target).closest('.adm-modal-content').length ) {
            closeModal();
        }
    });

    // Переключение вкладок в формах
    $('.tab-btn').click(function() {
        var tabId = $(this).data('tab');
        $('.adm-table').hide();
        $('#' + tabId).show();
        $('.tab-btn').removeClass('active');
        $(this).addClass('active');
    });
});

// Открытие модального окна
function loadModal(url, ajax_mode = 'Y') {
    let link =  url + '?ajax_mode=Y';
    console.log(link);
    $.ajax({
        url:  link,
        type: "GET",
        data: {'ajax_mode': ajax_mode},
        error: function(err){
            // console.log('error');
            // console.log(err);
        },
        beforeSend: function(data){
            // console.log('beforeSend');
            // console.log(data);
        },
        success: function(prem){
            $('.adm-modal-body').html(prem);
            $('.adm-modal').addClass('active');
        }
    });

    console.log(url);
}

function closeModal() {
    $('.adm-modal').removeClass('active');
    $('.adm-modal-body').empty();
}

// Раскрытие элемента древа в боковом меню
function toggleTreeItem(event) {
    $(event.target).parent().toggleClass('opened');
}

// Преобразование строки в адресный вид
function prepareStringForAddress(originalTitle) {
    let title = originalTitle.toLowerCase();
    let replaceChar = '_';
  
    title = title.replace(/[\s.,\/#!?$%\^&\*;:{}=\-+_`~()'"']/g, replaceChar);
    title = title.trim();
    title = transliterate(title);
    title = title.replace(/^_+/g, '').replace(/_+$/g, '');
    title = title.replace(RegExp(`${replaceChar}{2,}`, 'g'), replaceChar);
  
    return title;
}

// Транслитерация строки
function transliterate(text) {
    text = text
        .replace(/\u0401/g, 'YO') // символ: Ё
        .replace(/\u0419/g, 'I') // символ: И
        .replace(/\u0426/g, 'TS') // символ: Ц
        .replace(/\u0423/g, 'U') // символ: У
        .replace(/\u041A/g, 'K') // символ: К
        .replace(/\u0415/g, 'E') // символ: Е
        .replace(/\u041D/g, 'N') // символ: Н
        .replace(/\u0413/g, 'G') // символ: Г
        .replace(/\u0428/g, 'SH') // символ: Ш
        .replace(/\u0429/g, 'SCH') // символ: Щ
        .replace(/\u0417/g, 'Z') // символ: З
        .replace(/\u0425/g, 'H') // символ: Х
        .replace(/\u042A/g, '') // символ: Ъ
        .replace(/\u0451/g, 'yo') // символ: ё
        .replace(/\u0439/g, 'i') // символ: и
        .replace(/\u0446/g, 'ts') // символ: ц
        .replace(/\u0443/g, 'u') // символ: у
        .replace(/\u043A/g, 'k') // символ: к
        .replace(/\u0435/g, 'e') // символ: е
        .replace(/\u043D/g, 'n') // символ: н
        .replace(/\u0433/g, 'g') // символ: г
        .replace(/\u0448/g, 'sh') // символ: ш
        .replace(/\u0449/g, 'sch') // символ: щ
        .replace(/\u0437/g, 'z') // символ: з
        .replace(/\u0445/g, 'h') // символ: х
        .replace(/\u044A/g, "") // символ: ь
        .replace(/\u0424/g, 'F') // символ: Ф
        .replace(/\u042B/g, 'I') // символ: Ы
        .replace(/\u0412/g, 'V') // символ: В
        .replace(/\u0410/g, 'a') // символ: А
        .replace(/\u041F/g, 'P') // символ: П
        .replace(/\u0420/g, 'R') // символ: Р
        .replace(/\u041E/g, 'O') // символ: О
        .replace(/\u041B/g, 'L') // символ: Л
        .replace(/\u0414/g, 'D') // символ: Д
        .replace(/\u0416/g, 'ZH') // символ: Ж
        .replace(/\u042D/g, 'E') // символ: Э
        .replace(/\u0444/g, 'f') // символ: ф
        .replace(/\u044B/g, 'i') // символ: ы
        .replace(/\u0432/g, 'v') // символ: в
        .replace(/\u0430/g, 'a') // символ: а
        .replace(/\u043F/g, 'p') // символ: п
        .replace(/\u0440/g, 'r') // символ: р
        .replace(/\u043E/g, 'o') // символ: о
        .replace(/\u043B/g, 'l') // символ: л
        .replace(/\u0434/g, 'd') // символ: д
        .replace(/\u0436/g, 'zh') // символ: ж
        .replace(/\u044D/g, 'e') // символ: э
        .replace(/\u042F/g, 'Ya') // символ: Я
        .replace(/\u0427/g, 'CH') // символ: Ч
        .replace(/\u0421/g, 'S') // символ: С
        .replace(/\u041C/g, 'M') // символ: М
        .replace(/\u0418/g, 'I') // символ: И
        .replace(/\u0422/g, 'T') // символ: Т
        .replace(/\u042C/g, "") // символ: Ь
        .replace(/\u0411/g, 'B') // символ: Б
        .replace(/\u042E/g, 'YU') // символ: Ю
        .replace(/\u044F/g, 'ya') // символ: я
        .replace(/\u0447/g, 'ch') // символ: ч
        .replace(/\u0441/g, 's') // символ: с
        .replace(/\u043C/g, 'm') // символ: м
        .replace(/\u0438/g, 'i') // символ: и
        .replace(/\u0442/g, 't') // символ: т
        .replace(/\u044C/g, "") // символ: ъ
        .replace(/\u0431/g, 'b') // символ: б
        .replace(/\u044E/g, 'yu'); // символ: ю

    return text;
};

