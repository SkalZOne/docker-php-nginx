<?
// $a = content::getElementProperty(1,1);
// $item = classes\content::getElement(1,1);
// $item['PROPERTY'] = classes\content::getElementProperty(1,1,'notab');
// $item['PROPERTY'] = classes\content::getElementProperty(1,1);
// classes\backup::backupFile('server');

/* 
$backupDir = $_SERVER['DOCUMENT_ROOT'] . '/backup/'; // Путь к директории для резервных копий
$backupFilename = 'backup_' . date('Y-m-d_H-i-s') . '.zip'; // Имя файла резервной копии
 $backupFilepath = $backupDir . '/' . $backupFilename;



$zip = new ZipArchive();
        if ($zip->open($backupFilepath, ZipArchive::CREATE) !== true) {
			return 'Ошибка создание резервной копии. Не удалость создать архив.';
        }

			$ftp =  classes\core::connectFTP(1);
            $files =  classes\core::getFilesFromFTP($ftp, '/');
            foreach ($files as $file) {
                $localFile = tempnam(sys_get_temp_dir(), 'ftp_backup_');
                if (classes\core::downloadFileFromFTP($ftp, $file, $localFile)) {
                    if (!$zip->addFile($localFile, $file)) {
                        unlink($localFile); // Удаляем временный файл
                        // throw new \Exception("Ошибка при добавлении файла '$file' в архив.");
                    }
                    unlink($localFile); // Удаляем временный файл
                } else {
                    // throw new \Exception("Ошибка загрузки файла '$file' с FTP-сервера.");
                }
            }

 */
 
 
/* 
$ftpData = classes\core::getFTP(2,'type');
foreach( $ftpData as $code=>$value ){
	$arr[$value['adm_id']] = $value;
	$ftp[$value['adm_id']] = classes\core::connectFTP($value['adm_id'],$arr);
	$localFile = $_SERVER['DOCUMENT_ROOT'].'/backup/backup_2024-12-01_01-20-06.zip';
	$remoteFile = '/backup_2024-12-01_01-20-06.zip';
	classes\core::uploadFileFromFTP($ftp[$value['adm_id']], $remoteFile, $localFile);
}
 */
?>
<pre>
<?//=json_encode($item)?>
<?print_r($ftp);?>
</pre>