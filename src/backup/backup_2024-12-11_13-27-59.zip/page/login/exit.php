<?
classes\user::logout();
?>