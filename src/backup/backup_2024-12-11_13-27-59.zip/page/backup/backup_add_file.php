<?
$FTPServers = classes\server::getAllServerAccess('ftp');
?>


<form action="" method="POST">	
    <input type="hidden" name="form[teh_action]" value="Y" />
    <input type="hidden" name="form[teh_function]" value="createBackup" />
    <input type="hidden" name="form[teh_classes]" value="backup" />
    <input type="hidden" name="form[teh_backup_type]" value="0" />
    <div class="adm-detail">
        <div class="tab-content">
            <div class="tabs">
                <div class="tab-btn active" data-tab="tab1">Создать</div>
            </div>

            <table class="adm-table tab1" id="tab1">

                <tr class="heading">
                    <td colspan="2"><strong>Создать бекап файлов</strong></td>
                </tr>

                <tr>
                    <td class="adm-detail-content-cell-l"><strong>Исходный сервер:</strong></td>
                    <td>
                        <select name="form[adm_source]" size="5">
                            <option value="0">local</option>
                            <?foreach( $FTPServers as $server ) {?>
                                <option value="<?=$server['adm_id']?>">
                                    <?=classes\core::decryptData($server['adm_name'])?>
                                </option>
                            <?}?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td class="adm-detail-content-cell-l"><strong>Сервер хранения:</strong></td>
                    <td>
                        <select name="form[adm_backup]" size="5">
                            <option value="0">local</option>
                            <?foreach( $FTPServers as $server ) {?>
                                <option value="<?=$server['adm_id']?>">
                                    <?=classes\core::decryptData($server['adm_name'])?>
                                </option>
                            <?}?>
                        </select>
                    </td>
                </tr>
            </table>   

            <div class="adm-detail-footer">
                <input type="submit" name="action" class="adm-detail-but1" value="Сохранить">
                <a href="#" class="adm-detail-but2" >Отменить</a>
            </div>
    </div>
</form>