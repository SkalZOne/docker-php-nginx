<?

$detail = array();
if( isset($_REQUEST['id']) && $_REQUEST['id'] != '' ){
	
	$detail = classes\content::getElement($_REQUEST['content'], $_REQUEST['id']);
	$prop = classes\content::getElementProperty($_REQUEST['content'],$_REQUEST['id']);
	
	foreach( $prop as $value ){
		foreach( $value['item'] as $v ){
			$propVal[$v['pr_id']] = $v;
		}
	}

}elseif( isset($_REQUEST['ajax_mode']) && $_REQUEST['ajax_mode'] == 'Y' && 
		isset($_REQUEST['form_action']) && $_REQUEST['form_action'] == 'N' ){
			foreach( $_POST['form']['prop'] as $code=>$value ){
				$propVal[$code]['pr_value'] = $value;
			}
}

// echo '<pre>';
// print_r($propVal);
// echo '</pre>';

require $_SERVER['DOCUMENT_ROOT'] . '/template/diseases.php';

?>