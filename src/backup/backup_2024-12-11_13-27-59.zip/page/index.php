<?
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
session_start();

require $_SERVER['DOCUMENT_ROOT'] . '/vendor/autoload.php';

$header = true;
	
$basePath = $_SERVER['DOCUMENT_ROOT'] . '/page/';
$requestedPath = isset($_REQUEST['path']) ? $_REQUEST['path'] : '';
$decodedPath = urldecode($requestedPath);

if( !isset($_SESSION['user_id']) ){ //ЕСЛИ НУЖНА АВТОРИЗАЦИЯ
	$header = false;
	$realPath = realpath($basePath . 'login/index.php');
	require $realPath;
	exit;
}elseif ($decodedPath === '' || $decodedPath === '/') { //ЕСЛИ ЗАПРОШЕН КОРЕНЬ
    $realPath = realpath($basePath . 'index/index.php');
} else { //ПРОСТО СТРАНИЦА
	if( substr($decodedPath, -1) === '/'){
        $decodedPath .= 'index.php';
    }
    $realPath = realpath($basePath . $decodedPath);
}

if( isset($_GET['ajax_mode']) && $_GET['ajax_mode'] == 'Y' )
	$header = false;

if( $realPath !== false && strpos($realPath, $basePath) === 0 ) {
    if(is_file($realPath)){
		

		if( ($pos = strpos($_REQUEST['path'], '/')) !== false){
		   $module = substr($_REQUEST['path'], 0, $pos);
		}else{
			$module = false; 
		}
		
		//ПРОВЕРКА ПЕРЕДАННЫХ С ФОРМЫ ДАННЫХ
		if( isset($_REQUEST['form']['teh_action']) && $_REQUEST['form']['teh_action'] == 'Y' )
			require $_SERVER['DOCUMENT_ROOT'] . '/page/action.php';
		
		//ПОДКЛЮЧАЕМ ШАПКУ КОГДА ОНА НУЖНА(исключение только логин)
		if( $header )
			require $_SERVER['DOCUMENT_ROOT'] . '/page/header.php';
		
		//ВЫВОДИМ СТРАНИЦУ
        require $realPath;
        exit;
    }
}

require $basePath . '404.php';
?>