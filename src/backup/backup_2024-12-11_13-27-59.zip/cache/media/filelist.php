<?php return array (
  1 => 
  array (
    'name' => 'Картинки',
    'item' => 
    array (
      1 => 
      array (
        0 => 
        array (
          'adm_id' => 8,
          'adm_src' => 'https://file.rmp-portal.ru/media/1otbdd1/6722810d41ea9.png',
          'adm_section' => 1,
          'adm_description' => '111',
          'adm_section_id' => 1,
          'adm_section_name' => 'Картинки',
        ),
        1 => 
        array (
          'adm_id' => 12,
          'adm_src' => 'https://file.rmp-portal.ru/media/1otbdd1/67228138da598.png',
          'adm_section' => 1,
          'adm_description' => '112',
          'adm_section_id' => 1,
          'adm_section_name' => 'Картинки',
        ),
      ),
    ),
  ),
  2 => 
  array (
    'name' => 'Иконки',
    'item' => 
    array (
      1 => 
      array (
        0 => 
        array (
          'adm_id' => 13,
          'adm_src' => 'https://file.rmp-portal.ru/media/1otbdd1/67228138da9c6.png',
          'adm_section' => 2,
          'adm_description' => '113',
          'adm_section_id' => 2,
          'adm_section_name' => 'Иконки',
        ),
      ),
    ),
  ),
);