<?
namespace classes;
class login{
	public static function test(){
		return 'GO51';
	}
}
?>