<?php

namespace classes;

class text_editor{
    

    public static function spawnTextEditor($name='', $value='') {
        $template_dir = '/home/i/infoaqtl/admin.rmp-portal.ru/public_html/assets/lib/text-editor/editor-template.html';

        $content = file_get_contents($template_dir);
        
        $content = str_replace(
            '<textarea name="" id="html-editor"></textarea>', 
            '<textarea name="'. $name .'" id="html-editor">' . $value . '</textarea>', 
            $content);

        $content = str_replace(
            '<div id="editor" contentEditable></div>', 
            '<div id="editor" contentEditable>' . $value . '</div>', 
            $content);

        return $content;
    }
}