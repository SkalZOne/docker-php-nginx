<?php
namespace classes;

use ZipArchive; //Включили пространство имен для ZipArchive
use RecursiveIteratorIterator;
use RecursiveDirectoryIterator;
// Не нужно использовать PDO, если мы не работаем с базой данных в этом классе


class backup {

    public static function getBackupTypes() {
        return array(
            '0' => 'Файлы',
            '1' => 'База данных'
        );
    }

    public static function createBackupFile($source = 'local', $backup = 'local', $arr = array()) { 
        $sourceDir = $_SERVER['DOCUMENT_ROOT']; // Путь к директории, которую нужно резервировать
		$backupDir = $_SERVER['DOCUMENT_ROOT'] . '/backup/'; // Путь к директории для резервных копий

        $backupDate = date('Y-m-d_H-i-s');
        $backupFilename = 'backup_' . $backupDate . '.zip'; // Имя файла резервной копии

        // Проверка существования исходной директории
        if( !is_dir($sourceDir) ){
            return false;
        }

        // Проверка и создание директории для резервных копий
        if( !is_dir($backupDir) ){
            if (!mkdir($backupDir, 0755, true)) {
				return false;
            }
        }

        // Полный путь к файлу резервной копии
        $backupFilepath = $backupDir . $backupFilename;

        // Создание архива zip
        $zip = new ZipArchive();
        if( $zip->open($backupFilepath, ZipArchive::CREATE) !== true ) {
			return false;
        }
		
		
		if( $source === 'local' ){
			$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($sourceDir));
			foreach( $files as $file ){
				if( $file->isFile() ) {
					$filePath = $file->getRealPath();
					$relativePath = substr($filePath, strlen($sourceDir) + 1); // Относительный путь внутри архива

                    if( pathinfo($relativePath)['dirname'] === 'backup' ){
                        continue;
                    }

					if( !$zip->addFile($filePath, $relativePath) ) {
						return false;
					}
				}
			}
		} else if( $source === 'server' ){
            $ftp = core::connectFTP($arr['source_id']);
            $files = self::ftpGetAllFIles($ftp);

            foreach( $files as $file ) {
                if( self::isFtpDir($ftp, $file) ) {
                    $zip->addEmptyDir(mb_substr($file, 1));
                    continue;
                }
                
                $tempFile = tempnam(sys_get_temp_dir(), 'ftp_backup_');

                if( !ftp_get($ftp, $tempFile, $file, FTP_BINARY) ){
                    unlink($tempFile);
                    return false;
                }

                if (!$zip->addFile($tempFile, mb_substr($file, 1))) {
                    unlink($tempFile);
                    return false;
                }
            }

		}

        $zip->close();


		if ($backup === 'server') {
            $ftp = core::connectFTP($arr['backup_id']);
			$ftp_path = '/backup/';
            
            // Проверка существования директории backup
            if( !self::isFtpDir($ftp, $ftp_path) ) {
                ftp_mkdir($ftp, $ftp_path);
            }

            if( !ftp_put($ftp, $ftp_path . $backupFilename, $backupFilepath) ){
				return false;
			}

			ftp_close($ftp);
			unlink($backupFilepath);
		}

        return array(
            'adm_name' => $backupFilename,
            'adm_date' => $backupDate
        );
    }

    // Рекурсивное получение всех файлов в директории фтп сервера
    public static function ftpGetAllFIles($ftp, $currentDirectory='/', $list=array(), $first=TRUE, $exceptionDirs=['backup']) {
        if( !self::isFtpDir($ftp, $currentDirectory) ){
            
            // Если директория не существует
            if($first == TRUE){ 
                return "Path doesn't Exist (".$currentDirectory.")"; 
            }

            $list[] = $currentDirectory;

            return $list;
        } else {
            $contents = ftp_nlist($ftp, $currentDirectory);

            // Если директория  пустая
            if( count($contents) == 0 ){
                $list[] = $currentDirectory;
                return $list;
            }

            // Игнор некоторых директорий
            if( in_array(pathinfo($currentDirectory)['basename'], $exceptionDirs) ){
                return $list;
            }

            // Рекурсивный запуск для проверки всех директорий
            foreach( $contents as $file) {
                $list = self::ftpGetAllFIles($ftp, $file, $list, FALSE);
            }

            return $list;
        }
    }

    // Проверка является ли объект директорией
    public static function isFtpDir($ftp, $dir) {
        $curDir = ftp_pwd($ftp);
        if( @ftp_chdir($ftp, $dir) ){
            ftp_chdir($ftp, $curDir);
            return true;
        } else {
            return false;
        }
    }

    // Создание бекапа
    // примечания:
    // универсальная функция для создания бекапа как бд, так и файлов
    // 
    public static function createBackup() {
        $DBH = core::connectDB();
		$data = $_POST['form'];

        // Создание бекапа файлов
        if( $data['teh_backup_type'] === '0' ) {
            $backupSource = ( $data['adm_source'] === '0' ) ? 'local' : 'server';
            $backupDir = ( $data['adm_backup'] === '0' ) ? 'local' : 'server';

            echo $backupSource . '<br>';
            echo $backupDir . '<br>';

            $arr = [
                'source_id' => $data['adm_source'],
                'backup_id' => $data['adm_backup']
            ];

            $backupData = self::createBackupFile($backupSource, $backupDir, $arr);

            if( $backupData !== false ) {
                $sql = "INSERT INTO `adm_backup` 
                            (`adm_name`, `adm_type`, `adm_date`, `adm_source`, `adm_backup`)
                        VALUES 
                            (:adm_name, :adm_type, :adm_date, :adm_source, :adm_backup)";
                // $stmt = $DBH->prepare($sql);
                // $stmt->execute([
                //     ':adm_name' => $backupData['adm_name'],
                //     ':adm_type' => '0',
                //     ':adm_date' => $backupData['adm_date'],
                //     ':adm_source' => $data['adm_source'],
                //     ':adm_backup' => $data['adm_backup']
                // ]);
            }
        }
    }

    public static function test(): string { // Добавили тип возвращаемого значения
        return 'GO51';
    }
}
?>

