<?php
    $DBServers = classes\server::getAllServerAccess('db');
?>


<form action="" method="POST">	
    <input type="hidden" name="form[teh_action]" value="Y" />
    <input type="hidden" name="form[teh_function]" value="updateServerAccess" />
    <input type="hidden" name="form[teh_classes]" value="server" />
    <input type="hidden" name="form[teh_server_type]" value="db" />
    <div class="adm-detail">
        <div class="tab-content">
            <div class="tabs">
                <div class="tab-btn active" data-tab="tab1">Изменить</div>
            </div>

            <table class="adm-table tab1" id="tab1">

                <?foreach( $DBServers as $server ) {?>
                    <?
                    $DecryptedName = classes\core::decryptData($server['adm_name']);
                    $DecryptedUser = classes\core::decryptData($server['adm_user']);
                    $DecryptedPassword = classes\core::decryptData($server['adm_password']);
                    $DecryptedServer = classes\core::decryptData($server['adm_server']);
                    ?>
                    <tr class="heading">
                        <td colspan="2"><strong><?=$DecryptedName?></strong></td>
                    </tr>

                    <tr>
                        <td class="adm-detail-content-cell-l"><strong>Название:</strong></td>
                        <td>
                            <input type="text" style="width: 75%" 
                                    name="form[newData][<?=$server['adm_id']?>][adm_name]" 
                                    value="<?=$DecryptedName?>">
                            <input class="adm-detail-content-oldInput" type="text" style="width: 75%" 
                                    name="form[oldData][<?=$server['adm_id']?>][adm_name]" 
                                    value="<?=$DecryptedName?>" readonly>
                        </td>
                    </tr>

                    <tr>
                        <td class="adm-detail-content-cell-l"><strong>Пользователь:</strong></td>
                        <td>
                            <input type="text" style="width: 75%" 
                                    name="form[newData][<?=$server['adm_id']?>][adm_user]" 
                                    value="<?=$DecryptedUser?>">
                            <input class="adm-detail-content-oldInput" type="text" style="width: 75%" 
                                    name="form[oldData][<?=$server['adm_id']?>][adm_user]" 
                                    value="<?=$DecryptedUser?>" readonly>
                        </td>
                    </tr>

                    <tr>
                        <td class="adm-detail-content-cell-l"><strong>Пароль:</strong></td>
                        <td>
                            <input type="text" style="width: 75%" 
                                    name="form[newData][<?=$server['adm_id']?>][adm_password]" 
                                    value="<?=$DecryptedPassword?>">
                            <input class="adm-detail-content-oldInput" type="text" style="width: 75%" 
                                    name="form[oldData][<?=$server['adm_id']?>][adm_password]" 
                                    value="<?=$DecryptedPassword?>" readonly>
                        </td>
                    </tr>

                    <tr>
                        <td class="adm-detail-content-cell-l"><strong>Сервер:</strong></td>
                        <td>
                            <input type="text" style="width: 75%" 
                                    name="form[newData][<?=$server['adm_id']?>][adm_server]" 
                                    value="<?=$DecryptedServer?>">
                            <input class="adm-detail-content-oldInput" type="text" style="width: 75%" 
                                    name="form[oldData][<?=$server['adm_id']?>][adm_server]" 
                                    value="<?=$DecryptedServer?>" readonly>
                        </td>
                    </tr>

                    <tr>
                        <td class="adm-detail-content-cell-l"><strong>Префикс:</strong></td>
                        <td>
                            <input type="text" style="width: 75%" 
                                    name="form[newData][<?=$server['adm_id']?>][adm_prefix]" 
                                    value="<?=$server['adm_prefix']?>">
                            <input class="adm-detail-content-oldInput" type="text" style="width: 75%" 
                                    name="form[oldData][<?=$server['adm_id']?>][adm_prefix]" 
                                    value="<?=$server['adm_prefix']?>" readonly>
                        </td>
                    </tr>
                <?}?>

            </table>   

            <div class="adm-detail-footer">
                <input type="submit" name="action" class="adm-detail-but1" value="Сохранить">
                <a href="#" class="adm-detail-but2" >Отменить</a>
            </div>
    </div>
</form>