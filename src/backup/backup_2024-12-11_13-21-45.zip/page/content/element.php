<?
if( isset($_REQUEST['content']) ){
	// $property = classes\content::getSectionProperty($_REQUEST['content']);
	
	// if( isset($_REQUEST['id']) )


	// $propValue = classes\content::getSection($_REQUEST['content'], 'id', $_REQUEST['id']);
	$detail = array();
	if( isset($_REQUEST['id']) && $_REQUEST['id'] != '' ){
		$detail = classes\content::getElement($_REQUEST['content'], $_REQUEST['id']);
		$prop = classes\content::getElementProperty($_REQUEST['content'],$_REQUEST['id']);
		// $val = classes\content::getSectionProperty($_REQUEST['content'],$_REQUEST['id']);
	}else{
		$prop = classes\content::getElementProperty($_REQUEST['content']);	
	}
}
?>

	
<pre>
<?//print_r($_SERVER);?>
<?//print_r($detail);?>
<?//print_r($prop);?>
<?//print_r($_POST);?> 
</pre>
	
	
	
	
	
	
	

<form action="" method="POST">	
					<input type="hidden" name="form[teh_action]" value="Y" />
					<input type="hidden" name="form[teh_content_id]" value="<?=$_REQUEST['content']?>" />
					<input type="hidden" name="form[teh_function]" value="<?=(isset($_REQUEST['id']))?'updateElement':'addElement';?>" />
					<input type="hidden" name="form[teh_classes]" value="content" />
					<input type="hidden" name="form[id]" value="<?=(isset($_REQUEST['id']) && $_REQUEST['id'] != '')?$_REQUEST['id']:0;?>" />
<div class="adm-detail">
    <div class="tab-content">
        <div class="tabs">
            <div class="tab-btn active" data-tab="tab1" data-tab="tab1">Главное</div>
			<?foreach( $prop as $code=>$value ){?>
				<div class="tab-btn" data-tab="tab_p_<?=$code?>"><?=$value['name']?></div>
			<?}?>
            <div class="tab-btn" data-tab="tab4" data-tab="tab4">Другое</div>
            <div class="tab-btn" data-tab="tab6" data-tab="tab6">SEO</div>
        </div>
        <table class="adm-table tab1" id="tab1">
			<?if( isset($_REQUEST['id']) ){?>
				<tr>
					<td class="adm-detail-content-cell-l">ID:</td>
					<td class="adm-detail-content-cell-r"><?=$detail['pr_id']?></td>
				</tr>
				<tr>
					<td class="adm-detail-content-cell-l">Создан:</td>
					<td class="adm-detail-content-cell-r"><?=$detail['pr_date_create']?></td>
				</tr>
				<tr>
					<td class="adm-detail-content-cell-l">Изменен:</td>
					<td class="adm-detail-content-cell-r"><?=$detail['pr_date_update']?></td>
				</tr>
			<?}?>
            <tr>
                <td class="adm-detail-content-cell-l"><strong>Название:</strong></td>
                <td>
					<input type="text" style="width: 75%" name="form[pr_name]" value="<?=$detail['pr_name']??'';?>">
					<input class="adm-detail-content-oldInput" type="text" style="width: 75%" name="oldform[pr_name]" readonly value="<?=$detail['pr_name']??'';?>">
				</td>
            </tr>
            <tr>
                <td class="adm-detail-content-cell-l"><strong>Символьный код:</strong></td>
                <td>
					<input type="text" style="width: 75%" name="form[pr_code]" value="<?=$detail['pr_code']??'';?>">
					<input class="adm-detail-content-oldInput" type="text" style="width: 75%" name="oldform[pr_code]" readonly value="<?=$detail['pr_code']??'';?>">
				</td>
            </tr>
            <tr>
                <td class="adm-detail-content-cell-l">Активность:</td>
                <td>
					<input type="checkbox" name="form[pr_action]" value="1" <?=($detail['pr_action']==1)?'checked':'';?>>
					<input class="adm-detail-content-oldInput" onclick="return false" type="checkbox" name="oldform[pr_action]" readonly value="1" <?=($detail['pr_action']==1)?'checked':'';?>>
				</td>
            </tr>
			
            <tr>
                <td class="adm-detail-content-cell-l">Сортировка:</td>
                <td>
					<input type="text" style="width: 75%" name="form[pr_sort]" value="<?=$detail['pr_sort']??'';?>">
					<input class="adm-detail-content-oldInput" type="text" style="width: 75%" name="oldform[pr_sort]" readonly value="<?=$detail['pr_sort']??'';?>">
				</td>
            </tr>
			<tr class="heading">
                <td colspan="2"><strong>Разделы:</strong></td>
            </tr>
            <tr>
                <td class="adm-detail-content-cell-l">Раздел:</td>
                <td>
					<? $sec = classes\content::getSection($_REQUEST['content'],'all_tree'); ?>		
					<select name="form[pr_section]" size="10" >
						<?=classes\content::buildTreeOptions($sec, $detail['pr_section']??null); ?>
					</select>
					<select class="adm-detail-content-oldInput" name="oldform[pr_section]" size="10">
						<?=classes\content::buildTreeOptions($sec, $detail['pr_section']??null); ?>
					</select>
				</td>
            </tr>
        </table>   
		<?foreach( $prop as $code=>$value ){?>
			<table class="adm-table prop_tab tab_p_<?=$code?>" id="tab_p_<?=$code?>" style="display:none;">
				<?foreach( $value['item'] as $c=>$v ){?>
					<?=classes\content::printFormElement($v);?>
				<?}?>
			</table>   
		<?}?>
        <div class="adm-detail-footer">
			<input type="submit" name="action" class="adm-detail-but1" value="Сохранить">
			<input type="submit" name="action" class="adm-detail-but2" value="На модерацию">
            <a href="/content/?content=<?=$_REQUEST['content']?>&id=<?=$detail['pr_section']??'';?>" class="adm-detail-but2" >Отменить</a>
			<input type="submit" name="action" class="adm-detail-but2" value="Предпросмотр" formaction="/content/template.php?ajax_mode=Y&form_action=N" formtarget="_blank">
        </div>
    </div>
	</form>