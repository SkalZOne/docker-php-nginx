<?
if( isset($_REQUEST['content']) ){
	 
	// $sectionPath = classes\content::getSection($_REQUEST['content']);
	$section = classes\content::filterTreeChildById($_REQUEST['content'], isset($_REQUEST['id']) && $_REQUEST['id'] != '' ? $_REQUEST['id'] : 0);
	if( isset($_REQUEST['id']) ){
		$sectionPath = classes\content::getBreadcrumbs($_REQUEST['content'],$_REQUEST['id']);
		$element = classes\content::getElementList($_REQUEST['content'], $_REQUEST['id']);
	}else{
		$element = null;
		$sectionPath = null;
	}
	?>

	<pre>
	<?//print_r($sectionPath);?>
	<?//print_r($section);?>
	<?//print_r($element);?>
	</pre>
	
	
	<div class="adm-main-content-container">
		<div class="adm-path">
			<a href="/" class="adm-path-item">Рабочий стол</a>
			<div class="adm-path-delimiter"></div>
			<!--
			<a href="/content/" class="adm-path-item">Контент</a>
			<div class="adm-path-delimiter"></div>
			-->
			<a href="?content=<?=$_REQUEST['content']?>" class="adm-path-item"><?=$contetnBlock[$_REQUEST['content']]['adm_name']?></a>
			<?if( $sectionPath ){?>
				<?foreach( $sectionPath as $value){?>
					<div class="adm-path-delimiter"></div>
					<a href="?content=<?=$_REQUEST['content']?>&id=<?=$value['pr_id']?>" class="adm-path-item"><?=$value['pr_name']?></a>
				<?}?>
			<?}?>
		</div>
		<div class="fs-3 fw-bold" style="margin-top: 1rem"><?=$contetnBlock[$_REQUEST['content']]['adm_name']?></div>
		<div class="adm-table-toolbar">
			<div class="adm-search col">
				<input class="adm-search-input" type="text" placeholder="Фильтр + Поиск">
				<svg width="20px" height="20px" viewBox="0 0 24 24" fill="none">
                    <path d="M15.7955 15.8111L21 21M18 10.5C18 14.6421 14.6421 18 10.5 18C6.35786 18 3 14.6421 3 10.5C3 6.35786 6.35786 3 10.5 3C14.6421 3 18 6.35786 18 10.5Z" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
			</div>

			<div class="adm-table-toolbar-buttons col-auto">
                <!-- Кнопка с шестеренкой
				<div class="adm-but-settings" onclick="$(this).toggleClass('activate')">
					<svg width="20px" height="20px" viewBox="0 0 1920 1920">
						<path d="M1703.534 960c0-41.788-3.84-84.48-11.633-127.172l210.184-182.174-199.454-340.856-265.186 88.433c-66.974-55.567-143.323-99.389-223.85-128.415L1158.932 0h-397.78L706.49 269.704c-81.43 29.138-156.423 72.282-223.962 128.414l-265.073-88.32L18 650.654l210.184 182.174C220.39 875.52 216.55 918.212 216.55 960s3.84 84.48 11.633 127.172L18 1269.346l199.454 340.856 265.186-88.433c66.974 55.567 143.322 99.389 223.85 128.415L761.152 1920h397.779l54.663-269.704c81.318-29.138 156.424-72.282 223.963-128.414l265.073 88.433 199.454-340.856-210.184-182.174c7.793-42.805 11.633-85.497 11.633-127.285m-743.492 395.294c-217.976 0-395.294-177.318-395.294-395.294 0-217.976 177.318-395.294 395.294-395.294 217.977 0 395.294 177.318 395.294 395.294 0 217.976-177.317 395.294-395.294 395.294" fill-rule="evenodd"/>
					</svg>
					<div class="adm-but-settings-dropdown-menu">
						<span>Excel</span>
					</div>
				</div>
				Кнопка с шестеренкой -->
                <div class="adm-but-addContent">
                    <a href="/content/section.php?content=<?=$_REQUEST['content']?>" class="mx-3">ДОБАВИТЬ РАЗДЕЛ</a>
                </div>
				<div class="adm-but-addElement">
					<a href="/content/element.php?content=<?=$_REQUEST['content']?>" class="mx-3">ДОБАВИТЬ ЭЛЕМЕНТ</a>
				</div>
			</div>
		</div>
        <div class="table-container">
            <table class="adm-table-content">
                <thead>
                <tr>
                    <th class="adm-table-content-checkbox px-2">
                        <input class="form-check-input" type="checkbox" value="" id="tableCheckbox">
                        <label class="form-check-label" for="tableCheckbox"><label>
                    </th>
                    <th class="adm-table-content-settings px-3">
                        <!-- ШЕСТЕРЕНКА
                        <svg width="15px" height="15px" viewBox="0 0 1920 1920" fill="var(--header-text-color-alt)">
                            <path d="M1703.534 960c0-41.788-3.84-84.48-11.633-127.172l210.184-182.174-199.454-340.856-265.186 88.433c-66.974-55.567-143.323-99.389-223.85-128.415L1158.932 0h-397.78L706.49 269.704c-81.43 29.138-156.423 72.282-223.962 128.414l-265.073-88.32L18 650.654l210.184 182.174C220.39 875.52 216.55 918.212 216.55 960s3.84 84.48 11.633 127.172L18 1269.346l199.454 340.856 265.186-88.433c66.974 55.567 143.322 99.389 223.85 128.415L761.152 1920h397.779l54.663-269.704c81.318-29.138 156.424-72.282 223.963-128.414l265.073 88.433 199.454-340.856-210.184-182.174c7.793-42.805 11.633-85.497 11.633-127.285m-743.492 395.294c-217.976 0-395.294-177.318-395.294-395.294 0-217.976 177.318-395.294 395.294-395.294 217.977 0 395.294 177.318 395.294 395.294 0 217.976-177.317 395.294-395.294 395.294" fill-rule="evenodd"/>
                        </svg>
                        ШЕСТЕРЕНКА -->
                    </th>
                    <th class="adm-table-content-sort"><span>Название</span></th>
                    <th class="adm-table-content-sort"><span>Активность</span></th>
                    <th class="adm-table-content-sort"><span>Сортировка</span></th>
                    <th class="adm-table-content-sort"><span>Дата изменения</span></th>
                    <th class="adm-table-content-sort"><span>ID раздела</span></th>
                    <th class="adm-table-content-sort"><span>Статус</span></th>
                </tr>
                </thead>
                <tbody>
				<?if( is_array($section) ){?>
					<?foreach( $section as $code=>$value ){?>
						<tr>
							<th class="adm-table-content-checkbox px-2">
								<input class="form-check-input" type="checkbox" value="" id="tableCheckbox">
								<label class="form-check-label" for="tableCheckbox"></label>
							</th>
							<th class="adm-table-content-dropdown px-3" onclick="$(this).toggleClass('activate')">
								<svg viewBox="0 0 24 24">
									<path d="M4 18L20 18" stroke="#000000" stroke-width="2" stroke-linecap="round"/>
									<path d="M4 12L20 12" stroke="#000000" stroke-width="2" stroke-linecap="round"/>
									<path d="M4 6L20 6" stroke="#000000" stroke-width="2" stroke-linecap="round"/>
								</svg>
								<div class="adm-table-content-dropdown-menu">
									<!--<span>Разделы</span>-->
									<!--<span>Элементы</span>-->
									<a href="/content/section.php?content=<?=$_REQUEST['content']?>&id=<?=$value['pr_id']?>">Изменить</a>
									<span>Удалить</span>
								</div>
							</th>
							<th class="adm-table-content-name">
							
<svg xmlns="http://www.w3.org/2000/svg" width="29" height="25" viewBox="0 0 29 25" fill="none">
	<path d="M5 6.4375C5 6.05625 5.15145 5.69062 5.42103 5.42103C5.69062 5.15145 6.05625 5 6.4375 5H10.6149C11.0144 4.99999 11.4039 5.12479 11.7289 5.35698L14.0836 7.03885C14.4086 7.27104 14.7981 7.39585 15.1976 7.39583H22.25C22.6312 7.39583 22.9969 7.54728 23.2665 7.81687C23.536 8.08645 23.6875 8.45208 23.6875 8.83333V18.4167C23.6875 18.7979 23.536 19.1635 23.2665 19.4331C22.9969 19.7027 22.6312 19.8542 22.25 19.8542H6.4375C6.05625 19.8542 5.69062 19.7027 5.42103 19.4331C5.15145 19.1635 5 18.7979 5 18.4167V6.4375Z" stroke="#1F53A7" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

								<a href="?content=<?=$_REQUEST['content']?>&id=<?=$value['pr_id']?>" class="ms-1"><?=$value['pr_name']?></a>
							</th>
							<th class="adm-table-content-actual">Да</th>
							<th class="adm-table-content-sort">100</th>
							<th class="adm-table-content-date">07.10.2024 16:23:26</th>
							<th class="adm-table-content-id"><?=$value['pr_id']?></th>
							<th class="adm-table-content-id">Активно</th>
						</tr>
					<? } ?>
				<? } ?>
				<?if( is_array($element) ){?>
					<?foreach( $element as $code=>$value ){?>
						<tr>
							<th class="adm-table-content-checkbox px-2">
								<input class="form-check-input" type="checkbox" value="" id="tableCheckbox">
								<label class="form-check-label" for="tableCheckbox"></label>
							</th>
							<th class="adm-table-content-dropdown px-3" onclick="$(this).toggleClass('activate')">
								<svg viewBox="0 0 24 24">
									<path d="M4 18L20 18" stroke="#000000" stroke-width="2" stroke-linecap="round"/>
									<path d="M4 12L20 12" stroke="#000000" stroke-width="2" stroke-linecap="round"/>
									<path d="M4 6L20 6" stroke="#000000" stroke-width="2" stroke-linecap="round"/>
								</svg>
								<div class="adm-table-content-dropdown-menu">
									<!--<span>Разделы</span>-->
									<!--<span>Элементы</span>-->
									<a href="/content/element.php?content=<?=$_REQUEST['content']?>&id=<?=$value['pr_id']?>">Изменить</a>
									<span>Удалить</span>
								</div>
							</th>
							<th class="adm-table-content-name">
								<!--
								<svg viewBox="0 0 16 16">
									<path d="M0 1H6L9 4H16V14H0V1Z" fill="#000000"/>
								</svg>
								-->
								<a href="/content/element.php?content=<?=$_REQUEST['content']?>&id=<?=$value['pr_id']?>" class="ms-1"><?=$value['pr_name']?></a>
							</th>
							<th class="adm-table-content-actual">Да</th>
							<th class="adm-table-content-sort">100</th>
							<th class="adm-table-content-date">07.10.2024 16:23:26</th>
							<th class="adm-table-content-id"><?=$value['pr_id']?></th>
							<th class="adm-table-content-id">Активно</th>
						</tr>
					<? } ?>
				<? } ?>

                </tbody>
            </table>
            <div class="adm-table-hud">
                <div class="adm-table-hud-marked">
                    <span>ОТМЕЧЕНО:</span>
                    <div class="text-black fw-bold ms-2">0</div>
                    <div class="text-black fw-bold mx-2">/</div>
                    <div class="text-black fw-bold">14</div>
                </div>
                <div class="adm-table-hud-all">
                    <span>ВСЕГО:</span>
                    <div class="text-black fw-bold ms-2">14</div>
                </div>
                <div class="pagination-container">
                    <ul class="pagination">
                        <li class="page-item"><a href="#" class="page-link">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="20" viewBox="0 0 16 20" fill="none">
<path d="M6.78333 9.86567L11 5.649L10.351 5L5.48533 9.86567L10.351 14.7313L11 14.0823L6.78333 9.86567Z" fill="#847E7E"/>
</svg>
						ПРЕДЫДУЩАЯ</a></li>
                        <li class="page-item active"><a href="#" class="page-link">1</a></li>
                        <li class="page-item"><a href="#" class="page-link">2</a></li>
                        <li class="page-item"><a href="#" class="page-link">3</a></li>
                        <li class="page-item"><a href="#" class="page-link">4</a></li>
                        <li class="page-item"><a href="#" class="page-link">5</a></li>
                        <li class="page-item disabled"><span class="page-link">...</span></li>
                        <li class="page-item"><a href="#" class="page-link">38</a></li>
                        <li class="page-item"><a href="#" class="page-link">СЛЕДУЮЩАЯ 
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="20" viewBox="0 0 16 20" fill="none" style="    transform: rotateY(180deg);">
<path d="M6.78333 9.86567L11 5.649L10.351 5L5.48533 9.86567L10.351 14.7313L11 14.0823L6.78333 9.86567Z" fill="#847E7E"/>
</svg>
						</a></li>
                    </ul>
                </div>
                <div class="pagination-container-menu">
                    <label for="items-per-page">НА СТРАНИЦЕ:</label>
                    <select id="items-per-page" name="items-per-page">
                        <option value="5">5</option>
                        <option value="10">10</option>
                        <option value="20">20</option>
                        <option value="50">50</option>
                    </select>
                </div>
            </div>
            <div class="toolbar">
                <button class="toolbar-action-btn">
<svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" viewBox="0 0 23 23" fill="none">
<path fill-rule="evenodd" clip-rule="evenodd" d="M12.8792 5.80002C13.3914 5.28778 14.0862 5 14.8106 5C15.535 5 16.2298 5.28778 16.742 5.80002C17.2542 6.31226 17.542 7.00701 17.542 7.73144C17.542 8.45586 17.2542 9.15061 16.742 9.66285L11.2085 15.1964C10.8923 15.5125 10.7068 15.698 10.4992 15.8596C10.2549 16.0509 9.99244 16.2133 9.71166 16.3467C9.47483 16.4593 9.22516 16.5427 8.80166 16.6839L6.858 17.3314L6.39016 17.4877C6.2041 17.5498 6.00441 17.5589 5.81348 17.5138C5.62256 17.4688 5.44795 17.3715 5.30925 17.2328C5.17054 17.0941 5.07322 16.9195 5.02819 16.7285C4.98316 16.5376 4.99222 16.3379 5.05433 16.1519L5.85816 13.7409C5.99933 13.3169 6.08275 13.0672 6.19533 12.8298C6.32911 12.5498 6.49147 12.2873 6.68241 12.0423C6.84341 11.8358 7.0295 11.6497 7.34566 11.3335L12.8792 5.80002ZM6.83758 16.4167L8.49483 15.8637C8.95625 15.7097 9.15225 15.6438 9.33483 15.5569C9.55728 15.4503 9.76591 15.3214 9.96075 15.1701C10.12 15.0453 10.267 14.9 10.6112 14.5559L15.027 10.14C14.4216 9.92548 13.872 9.57783 13.4187 9.12269C12.964 8.66934 12.6168 8.11976 12.4026 7.51444L7.98675 11.9303C7.64258 12.2739 7.49675 12.4203 7.3725 12.5801C7.22083 12.7745 7.09191 12.9832 6.98575 13.206C6.89883 13.3886 6.83291 13.5846 6.67891 14.046L6.12591 15.7044L6.83758 16.4167ZM13.1113 6.80452C13.1317 6.9066 13.165 7.04544 13.2216 7.20702C13.3922 7.6953 13.6715 8.13848 14.0382 8.50319C14.4028 8.86989 14.8458 9.14912 15.3338 9.31985C15.496 9.37644 15.6348 9.40969 15.7369 9.4301L16.1231 9.04394C16.4692 8.69542 16.663 8.22394 16.6622 7.73278C16.6613 7.24162 16.4658 6.77082 16.1185 6.42352C15.7712 6.07622 15.3004 5.88072 14.8092 5.87986C14.3181 5.87901 13.8466 6.07285 13.4981 6.41894L13.1113 6.80452Z" fill="#847E7E"/>
</svg>
                    РЕДАКТИРОВАТЬ</button>
                <button class="toolbar-action-btn">
                   <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
						<path d="M7 7L17.4167 17.4167M7 17.4167L17.4167 7" stroke="#847E7E" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
                    УДАЛИТЬ</button>
                <div class="toolbar-dropdown">
                    <button class="toolbar-dropdown-toggle">- ДЕЙСТВИЯ -
<svg xmlns="http://www.w3.org/2000/svg" width="21" height="16" viewBox="0 0 21 16" fill="none">
<path d="M15.8731 5.13949C15.9544 5.22166 16 5.33305 16 5.44918C16 5.56532 15.9544 5.67671 15.8731 5.75888L10.8122 10.8718C10.7308 10.9539 10.6206 11 10.5056 11C10.3906 11 10.2804 10.9539 10.1991 10.8718L5.13807 5.75888C5.09545 5.71876 5.06126 5.67038 5.03755 5.61662C5.01384 5.56286 5.0011 5.50483 5.00007 5.44598C4.99904 5.38714 5.00975 5.32869 5.03157 5.27412C5.05339 5.21955 5.08586 5.16998 5.12706 5.12836C5.16825 5.08675 5.21732 5.05394 5.27133 5.0319C5.32535 5.00985 5.3832 4.99903 5.44145 5.00007C5.4997 5.00111 5.55714 5.01399 5.61035 5.03794C5.66357 5.06189 5.71146 5.09643 5.75117 5.13949L10.5056 9.94274L15.26 5.13949C15.3414 5.05742 15.4516 5.01132 15.5666 5.01132C15.6815 5.01132 15.7918 5.05742 15.8731 5.13949Z" fill="#847E7E"/>
</svg>
                        </button>
                    <lable class="toolbar-dropdown-menu">
                        <lable><a href="#">Опция 1</a></lable>
                        <lable><a href="#">Опция 2</a></lable>
                    </lable>
                </div>
            </div>

<script>
    const dropdownToggle = document.querySelector('.toolbar-dropdown-toggle');
    const dropdownMenu = document.querySelector('.toolbar-dropdown');
    const menuOptions = document.querySelectorAll('.toolbar-dropdown-menu a');
    dropdownToggle.addEventListener('click', function(e) {
        e.stopPropagation();
        dropdownMenu.classList.toggle('active');
    });
    document.addEventListener('click', function(e) {
        if (!dropdownMenu.contains(e.target)) {
            dropdownMenu.classList.remove('active');
        }
    });
    menuOptions.forEach(option => {
        option.addEventListener('click', function() {
            dropdownMenu.classList.remove('active');
        });
    });
</script>
<? } ?> 