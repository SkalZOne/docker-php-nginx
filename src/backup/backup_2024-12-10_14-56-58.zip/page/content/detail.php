<?
if( isset($_REQUEST['content']) ){
// $section = classes\content::filterTreeChildById($_REQUEST['conent'], $_REQUEST['id']);
?>

<?}?>