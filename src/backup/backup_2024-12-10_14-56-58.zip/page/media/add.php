
<form action="" method="post" enctype="multipart/form-data">
	
	<input type="text" name="form[teh_action]" value="Y" /><br/>
	<input type="text" name="form[teh_classes]" value="media" /><br/>
	<input type="text" name="form[teh_function]" value="addMediaFile" /><br/><br/>
	
	<?$sec = classes\media::getSection(); ?>
	<select name="section" size="10">
		<?foreach( $sec as $value ){?>
			<option value="<?=$value['adm_id']?>"><?=$value['adm_name']?></option>
		<?}?>
	</select><br/><br/>
	<?for($i=0;$i<5;$i++){?>
		<input type="text" name="name[]" value="">
		<input type="file" name="uploaded_file[]">
		<br/>
	<?}?>
	
	<input type="submit" value="Upload"><br/>
</form>  