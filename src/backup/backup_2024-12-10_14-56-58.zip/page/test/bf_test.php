<?php

echo __DIR__;

echo "<pre>";
print_r(classes\media::getAllMedia());
echo "</pre>";

function checkAddressName($title, $minLen = 1, $maxLen = 100, $exceptionChar = '_') {
    // Проверка длины строки
    if( strlen($title) < $minLen || strlen($title) > $maxLen ){
        return false;
    }

    // Проверка на пробелы
    if( strpos($title, ' ') !== false ){
        return false;
    }

    // Проверка на нижний регистр и спецсимволы(игнорируя разделитель)
    if( !preg_match("/^[a-z0-9" . preg_quote($exceptionChar, '/') . "]+$/", $title) ) {
        return false;
    }

    return true;
}


echo checkAddressName("hello_world") . '<br>';
echo checkAddressName("Hello_world") . '<br>';
echo checkAddressName("!!Another!! Title!!") . '<br>';
echo checkAddressName("Title With, Commas.") . '<br>';
echo checkAddressName("Title/With/Slashes") . '<br>';
echo checkAddressName("Title With; Semicolons") . '<br>';
echo checkAddressName("$%^&*()_+=-") . '<br>';
echo checkAddressName("Привет, мир!") . '<br>';
echo checkAddressName("Ещё один тест.") . '<br>';
echo checkAddressName("Название с пробелами и  дополнительными пробелами.") . '<br>';
echo checkAddressName("12345 Числа и буквы") . '<br>';
echo checkAddressName("-Начало и конец -") . '<br>';
echo checkAddressName("_Подчеркивания_внутри_строки_") . '<br>';
echo checkAddressName(".Начало с точки") . '<br>';
echo checkAddressName("Конец с точкой.") . '<br>';
echo checkAddressName("Пример с (скобками)") . '<br>';
echo checkAddressName('Текст с кавычками "в кавычках"') . '<br>';
echo checkAddressName("Название статьи с очень длинным названием, чтобы проверить, как функция обрабатывает длинные строки") . '<br>';
echo checkAddressName("  Много   пробелов   ") . '<br>';
echo checkAddressName("Пустое название") . '<br>';

echo checkAddressName("hello world") . '<br>';
echo checkAddressName("test %title") . '<br>';
echo checkAddressName("another_title") . '<br>';
echo checkAddressName("title_with_commas") . '<br>';
echo checkAddressName("title_with_slashes") . '<br>';
echo checkAddressName("title_with_semicolons") . '<br>';
echo checkAddressName("123") . '<br>';
echo checkAddressName("privet_mir") . '<br>';
echo checkAddressName("eschyo_odin_test") . '<br>';
echo checkAddressName("nazvanie_s_probelami_i_dopolnitelnimi_probelami") . '<br>';
echo checkAddressName("12345_chisla_i_bukvi") . '<br>';
echo checkAddressName("nachalo_i_konets") . '<br>';
echo checkAddressName("podcherkivaniya_vnutri_stroki") . '<br>';
echo checkAddressName("nachalo_s_tochki") . '<br>';
echo checkAddressName("konets_s_tochkoi") . '<br>';
echo checkAddressName("primer_s_skobkami") . '<br>';
echo checkAddressName("tekst_s_kavichkami_v_kavichkah") . '<br>';
echo checkAddressName("nazvanie_stati_s_ochen_dlinnim_nazvaniem_chtobi_proverit_kak_funktsiya_obrabativaet_dlinnie_stroki") . '<br>';
echo checkAddressName("mnogo_probelov") . '<br>';
echo checkAddressName("pustoe_nazvanie") . '<br>';
