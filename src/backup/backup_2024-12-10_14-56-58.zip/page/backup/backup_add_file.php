<?php

print_r(classes\backup::backupFIle('server', 'local', ['server_id' => 4]));


// echo '<pre>';
// echo 'a_file.txt: pathinfo is ' . '<br>';
// print_r(pathinfo('a_file.txt')) . "\n";

// echo '</pre>';



// echo '<pre>';
// echo 'bin: pathinfo is ' . '<br>';
// print_r(pathinfo('bin')) . "\n";

// echo '</pre>';


// echo '<pre>';
// echo '/usr/bin: pathinfo is ' . '<br>';
// print_r(pathinfo('/usr/bin')) . "\n";

// echo '</pre>';





echo '<pre>';

// $ftp = classes\core::connectFTP(4);

// var_dump( classes\backup::isFtpDir($ftp, '/backup/') );


// $ftpFiles = classes\backup::ftpGetAllFIles($ftp);

// print_r($ftpFiles);

// print_r($ftpFiles);
// foreach( $ftpFiles as $file ) {
//     echo mb_substr($file, 1) . '<br>';
// }
// $sourceDir = $_SERVER['DOCUMENT_ROOT'];
// $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($sourceDir));
// foreach( $files as $file ) {
//     $filePath = $file->getRealPath();
// 	$relativePath = substr($filePath, strlen($sourceDir) + 1);
//     echo $file . '<br>';
//     echo $relativePath . '<br><br>';
// }
echo '</pre>';
?>