<?php
namespace classes;

use ZipArchive; //Включили пространство имен для ZipArchive
use RecursiveIteratorIterator;
use RecursiveDirectoryIterator;
// Не нужно использовать PDO, если мы не работаем с базой данных в этом классе


class backup {

    public static function backupFile($backup = 'local', $source = 'local', $arr = array()){ 
        $sourceDir = $_SERVER['DOCUMENT_ROOT']; // Путь к директории, которую нужно резервировать
		$backupDir = $_SERVER['DOCUMENT_ROOT'] . '/backup/'; // Путь к директории для резервных копий
        $backupFilename = 'backup_' . date('Y-m-d_H-i-s') . '.zip'; // Имя файла резервной копии

        // Проверка существования исходной директории
        if( !is_dir($sourceDir) ){
            return 'Ошибка при создании резервной копии. Исходная директория не существует.';
        }

        // Проверка и создание директории для резервных копий
        if( !is_dir($backupDir) ){
            if (!mkdir($backupDir, 0755, true)) {
				return 'Ошибка при создании резервной копии. Невозможно найти и/или создать директорию сохранения.';
            }
        }

        // Полный путь к файлу резервной копии
        $backupFilepath = $backupDir . $backupFilename;

        // Создание архива zip
        $zip = new ZipArchive();
        if( $zip->open($backupFilepath, ZipArchive::CREATE) !== true ) {
			return 'Ошибка при создании резервной копии. Ошибка при создании архива.';
        }
		
		
		if( $source === 'local' ){
			$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($sourceDir));
			foreach( $files as $file ){
				if( $file->isFile() ) {
					$filePath = $file->getRealPath();
					$relativePath = substr($filePath, strlen($sourceDir) + 1); // Относительный путь внутри архива

                    if( pathinfo($relativePath)['dirname'] === 'backup' ){
                        continue;
                    }

					if( !$zip->addFile($filePath, $relativePath) ) {
						return 'Ошибка при создании резервной копии. Ошибка при добавлении файла.';
					}
				}
			}
		} else if( $source === 'server' ){
            $ftp = core::connectFTP($arr['server_id']);
            $files = self::ftpGetAllFIles($ftp);

            foreach( $files as $file ) {
                if( self::isFtpDir($ftp, $file) ) {
                    $zip->addEmptyDir(mb_substr($file, 1));
                    continue;
                }
                
                $tempFile = tempnam(sys_get_temp_dir(), 'ftp_backup_');

                if( !ftp_get($ftp, $tempFile, $file, FTP_BINARY) ){
                    unlink($tempFile);
                    return "Ошибка скачивания файла с FTP. Файл: " . $file;
                }

                if (!$zip->addFile($tempFile, mb_substr($file, 1))) {
                    unlink($tempFile);
                    return "Ошибка добавления файла в архив. Файл: " . $relativePath;
                }
            }

		}

        $zip->close();


		if ($backup === 'server') {
            $ftp = core::connectFTP($arr['server_id']);
			$ftp_path = '/backup/';
            
            // Проверка существования директории backup
            if( !self::isFtpDir($ftp, $ftp_path) ) {
                ftp_mkdir($ftp, $ftp_path);
            }

            if( !ftp_put($ftp, $ftp_path . $backupFilename, $backupFilepath) ){
				return 'Ошибка создание резервной копии. Ошибка загрузки файла на FTP-сервер.';
			}

			ftp_close($ftp);
			unlink($backupFilepath);

			return "Резервная копия успешно создана и загружена на FTP-сервер.";
		}

        return 'Резервная копия успешно создана.';
    }

    // Рекурсивное получение всех файлов в директории фтп сервера
    public static function ftpGetAllFIles($ftp, $currentDirectory='/', $list=array(), $first=TRUE, $exceptionDirs=['backup']){
        if( !self::isFtpDir($ftp, $currentDirectory) ){
            
            // Если директория не существует
            if($first == TRUE){ 
                return "Path doesn't Exist (".$currentDirectory.")"; 
            }

            $list[] = $currentDirectory;

            return $list;
        } else {
            $contents = ftp_nlist($ftp, $currentDirectory);

            // Если директория  пустая
            if( count($contents) == 0 ){
                $list[] = $currentDirectory;
                return $list;
            }

            // Игнор некоторых директорий
            if( in_array(pathinfo($currentDirectory)['basename'], $exceptionDirs) ){
                return $list;
            }

            // Рекурсивный запуск для проверки всех директорий
            foreach( $contents as $file) {
                $list = self::ftpGetAllFIles($ftp, $file, $list, FALSE);
            }

            return $list;
        }
    }

    // Проверка является ли объект директорией
    public static function isFtpDir($ftp, $dir) {
        $curDir = ftp_pwd($ftp);
        if( @ftp_chdir($ftp, $dir) ){
            ftp_chdir($ftp, $curDir);
            return true;
        } else {
            return false;
        }
    }

    public static function test(): string { // Добавили тип возвращаемого значения
        return 'GO51';
    }
}
?>

