<?
namespace classes;

use PDO;

class server{

	public static function getFTPServerTypes() {
		return array(
			'1' => 'Тип1',
			'2' => 'Тип2',
			'3' => 'Тип3'
		);
	}
	
	//получить данные сервера
	public static function getServer($admId, $type = 'id'){
		$DBH = core::connectDB();
		if ($type == 'id') {
			$stmt = $DBH->prepare("SELECT * FROM adm_server WHERE adm_id = :id");
		} elseif ($type == 'type') {
			$stmt = $DBH->prepare("SELECT * FROM adm_server WHERE adm_type = :type");
		}
		$stmt->execute([':type' => $admId]);

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
			
		return $result;
	}

	// Получаем записи обо всех доступах
	// type
	// 		db - все доступы бд
	// 		ftp - все доступы фтп
	public static function getAllServerAccess( $type ) {
		$DBH = core::connectDB();
		
		if( $type === 'db' ) {
			$sql = "SELECT * FROM adm_db";
		} else if( $type === 'ftp' ) {
			$sql = "SELECT * FROM adm_ftp";
		}

		$stmt = $DBH->query($sql);

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	public static function addServerAccess(){
		$DBH = core::connectDB();
		$data = $_POST['form'];
		
		// Добавление доступа бд
		if( $data['teh_server_type'] === 'db' ) {
			$sql = "INSERT INTO `adm_db` 
					(`adm_name`, `adm_user`, `adm_password`, `adm_server`, `adm_prefix`)
				VALUES 
					(:adm_name, :adm_user, :adm_password, :adm_server, :adm_prefix)";
			$stmt = $DBH->prepare($sql);
			$stmt->execute([
				':adm_name' => core::encryptData($data['adm_name']),
				':adm_user' => core::encryptData($data['adm_user']),
				':adm_password' => core::encryptData($data['adm_password']),
				':adm_server' => core::encryptData($data['adm_server']),
				':adm_prefix' => $data['adm_prefix']
			]);

		// Добавление доступа фтп
		} else if( $data['teh_server_type'] === 'ftp' ) {
			$sql = "INSERT INTO `adm_ftp` 
					(`adm_name`, `adm_password`, `adm_server`, `adm_type`)
				VALUES 
					(:adm_name, :adm_password, :adm_server, :adm_type)";
			$stmt = $DBH->prepare($sql);
			$stmt->execute([
				':adm_name' => core::encryptData($data['adm_name']),
				':adm_password' => core::encryptData($data['adm_password']),
				':adm_server' => core::encryptData($data['adm_server']),
				':adm_type' => $data['adm_type']
			]);
		}
	}

	public static function updateServerAccess(){
		$DBH = core::connectDB();
		
		$operationType = $_POST['form']['teh_server_type'];
		$newData = $_POST['form']['newData'];
		$oldData = $_POST['form']['oldData'];

		// Обновление доступов бд
		if( $operationType === 'db' ) {
			$sql = "UPDATE `adm_db` SET 
						`adm_name` = :adm_name, 
						`adm_user` = :adm_user, 
						`adm_password` = :adm_password, 
						`adm_server` = :adm_server, 
						`adm_prefix` = :adm_prefix 
					WHERE `adm_id` = :adm_id";

			$stmt = $DBH->prepare($sql);
			$DBH->beginTransaction();

			foreach( $newData as $dataID => $data ) {
				if( !empty(array_diff($data, $oldData[$dataID])) ) {
					$stmt->execute([
						':adm_name' => core::encryptData($data['adm_name']),
						':adm_user' => core::encryptData($data['adm_user']),
						':adm_password' => core::encryptData($data['adm_password']),
						':adm_server' => core::encryptData($data['adm_server']),
						':adm_prefix' => $data['adm_prefix'],
						':adm_id' => $dataID
					]);
				}
			}
		
		// Обновление доступов фтп
		} else if( $operationType === 'ftp' ) {
			$sql = "UPDATE `adm_ftp` SET 
						`adm_name` = :adm_name, 
						`adm_password` = :adm_password, 
						`adm_server` = :adm_server, 
						`adm_type` = :adm_type 
					WHERE `adm_id` = :adm_id";

			$stmt = $DBH->prepare($sql);
			$DBH->beginTransaction();

			foreach( $newData as $dataID => $data ) {
				if( !empty(array_diff($data, $oldData[$dataID])) ) {
					$stmt->execute([
						':adm_name' => core::encryptData($data['adm_name']),
						':adm_password' => core::encryptData($data['adm_password']),
						':adm_server' => core::encryptData($data['adm_server']),
						':adm_type' => $data['adm_type'],
						':adm_id' => $dataID
					]);
				}
			}
		}
		$DBH->commit();
	}
	
	

	public static function test(){
		return 'GO51'; 
	}
}
?>