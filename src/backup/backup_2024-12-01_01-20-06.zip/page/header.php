<!DOCTYPE html> 
<html lang="en">
<head>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<?require $_SERVER['DOCUMENT_ROOT'] . '/page/link.php';?>
    <title>Контент - aqirus-group.ru</title>
</head>
</head>
<body>
    <div class="adm-header">
        <div class="adm-header-left col">
            <div class="header-button button">Сайт</div>
            <div class="header-button button active">Администрирование</div>
            <div class="notification-button button">
                <svg viewBox="0 0 15 15">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M0 1.49933C0 0.670226 0.671178 0 1.5 0H13.5C14.3288 0 15 0.670226 15 1.49933V10.4935C15 11.3226 14.3288 11.9928 13.5 11.9928H7.66658L3.79988 14.8909C3.64835 15.0045 3.44568 15.0227 3.27632 14.938C3.10697 14.8533 3 14.6802 3 14.4908V11.9928H1.5C0.671178 11.9928 0 11.3226 0 10.4935V1.49933ZM4 3.99738H11V4.99738H4V3.99738ZM4 6.99542H9V7.99542H4V6.99542Z" fill="#000000"/>
                </svg>
                <div class="notification-count">1</div>
            </div>
        </div>
        <div class="adm-header-right col">
            <div class="header-search">
                <input type="text" placeholder="Поиск...">
                <svg width="20px" height="20px" viewBox="0 0 24 24" fill="none">
                    <path d="M15.7955 15.8111L21 21M18 10.5C18 14.6421 14.6421 18 10.5 18C6.35786 18 3 14.6421 3 10.5C3 6.35786 6.35786 3 10.5 3C14.6421 3 18 6.35786 18 10.5Z" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            <div class="header-link">
                <svg viewBox="0 0 24 24">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M1 12C1 5.92487 5.92487 1 12 1C18.0751 1 23 5.92487 23 12C23 18.0751 18.0751 23 12 23C5.92487 23 1 18.0751 1 12ZM10.3027 13.3942C10.2316 13.7147 10.5038 14 10.8479 14H13.0406C13.2979 14 13.5151 13.8351 13.6064 13.6061C13.697 13.3789 14.0117 12.9674 14.254 12.7518C14.4827 12.5112 14.7213 12.2848 14.9563 12.0618C15.8824 11.183 16.754 10.356 16.754 8.91047C16.754 6.40301 14.582 5 12.2707 5C10.5038 5 8.06416 5.80604 7.58396 8.50363C7.48716 9.04737 7.94773 9.5 8.50002 9.5H9.91229C10.4388 9.5 10.8312 9.07642 11.0121 8.582C11.1863 8.10604 11.5379 7.7551 12.2707 7.7551C13.6066 7.7551 13.6064 9.22371 12.8346 10.1843C12.5434 10.5467 12.2023 10.8677 11.8648 11.1853C11.1798 11.8298 10.5098 12.4602 10.3027 13.3942ZM13.9999 17C13.9999 18.1046 13.1045 19 11.9999 19C10.8954 19 9.99994 18.1046 9.99994 17C9.99994 15.8954 10.8954 15 11.9999 15C13.1045 15 13.9999 15.8954 13.9999 17Z" fill="#000000"/>
                </svg>
                Помощь
            </div>
            <div class="header-user header-link">
                <span><?=$_SESSION['user_login']?></span>
                <div class="header-user-dropdown">
                    <span>Редактировать</span>
                    <span>Выйти</span>
                </div>
            </div>
        </div>
        <div class="adm-modal active">
            <div class="adm-modal-body">
                <div class="adm-modal-exit"><i class="fa-regular fa-circle-xmark"></i></div>
            </div>
        </div>
    </div>
    <div class="adm-main">
        <div class="adm-sidebar">
		
            <a href="/" class="adm-sidebar-item <?=($module)?'':'active';?>">
                <svg viewBox="0 0 1024 1024">
                    <path fill="#000000" d="M128 320v576h576V320H128zm-32-64h640a32 32 0 0 1 32 32v640a32 32 0 0 1-32 32H96a32 32 0 0 1-32-32V288a32 32 0 0 1 32-32zM960 96v704a32 32 0 0 1-32 32h-96v-64h64V128H384v64h-64V96a32 32 0 0 1 32-32h576a32 32 0 0 1 32 32zM256 672h320v64H256v-64zm0-192h320v64H256v-64z"/>
                </svg>
                <span>Главная</span>
            </a>
            <a href="/content/" class="adm-sidebar-item <?=($module=='content')?'active':'';?>">
                <svg viewBox="0 0 1024 1024">
                    <path fill="#000000" d="M128 320v576h576V320H128zm-32-64h640a32 32 0 0 1 32 32v640a32 32 0 0 1-32 32H96a32 32 0 0 1-32-32V288a32 32 0 0 1 32-32zM960 96v704a32 32 0 0 1-32 32h-96v-64h64V128H384v64h-64V96a32 32 0 0 1 32-32h576a32 32 0 0 1 32 32zM256 672h320v64H256v-64zm0-192h320v64H256v-64z"/>
                </svg>
                <span>Контент</span>
            </a>
             <a href="/server/" class="adm-sidebar-item">
                <svg viewBox="0 0 1024 1024">
                    <path fill="#000000" d="M128 320v576h576V320H128zm-32-64h640a32 32 0 0 1 32 32v640a32 32 0 0 1-32 32H96a32 32 0 0 1-32-32V288a32 32 0 0 1 32-32zM960 96v704a32 32 0 0 1-32 32h-96v-64h64V128H384v64h-64V96a32 32 0 0 1 32-32h576a32 32 0 0 1 32 32zM256 672h320v64H256v-64zm0-192h320v64H256v-64z"/>
                </svg>
                <span>Сервера</span>
            </a>
        </div>
        <div class="adm-side-content" style="width: 300px;">
		
		<?
			if( $module == 'content' ){
				$contetnBlock = classes\content::getContentList();
				foreach( $contetnBlock as $code=>$value ){
					$menu[$code]['name'] = $value['adm_name'];
					$menu[$code]['url'] = "/content/index.php?content={$value['adm_id']}&id=";
					$menu[$code]['items'] = classes\content::getSection($value['adm_db_id'],'all_tree');
					
				}
		?>
            <div class="adm-side-content-container">
                <span class="fs-5" style="font-weight:500;">Контент</span>
                <div class="adm-tree">

                    <?=classes\content::printTreeSection($menu)?>
					
                </div>
            </div>
		<? } ?>
		
        </div>
        <script>
            $('.adm-side-content').resizable({
                direction: 'right',
                minWidth: 150
            });
        </script> 
        <div class="adm-main-content">