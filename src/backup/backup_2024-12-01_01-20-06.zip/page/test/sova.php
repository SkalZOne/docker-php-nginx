<?
// $a = content::getElementProperty(1,1);
// $item = classes\content::getElement(1,1);
// $item['PROPERTY'] = classes\content::getElementProperty(1,1,'notab');
// $item['PROPERTY'] = classes\content::getElementProperty(1,1);
classes\backup::backupFile();
?>
<pre>
<?//=json_encode($item)?>
<?//print_r($item);?>
</pre>