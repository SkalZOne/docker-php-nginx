<a href="/login/exit.php">выйти</a>
<br/>
<?//=classes\core::encryptData('localhost');?>
<br/>
<?//=classes\core::encryptData('aqirus_pr_diseas');?>
<br/>
<?//=classes\core::encryptData('aqirus_pr_diseas');?>
<br/>
<?//=classes\core::encryptData('aFKGAz1fS1%C');?>
<?//=classes\core::decryptData('HvkZoE04gQMMRD1ZrClJVSEcIqL8UzheiFyIaQtGcyqlV33BaCOI+tsWWx2XRDuDpEs/5CzcK09t4Af9UDJlUg==');?>

<? 
// $a = classes\core::other_connectdb(1);
$a = classes\content::getSection(1,'all_tree');
?>
<pre>
<?print_r($a);?>
</pre>
фыв
<?

?>


 