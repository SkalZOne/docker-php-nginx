<?
namespace classes;

use PDO;

class server{
	
	//получить данные сервера
	public static function getServer($admId, $type = 'id'){
		$DBH = core::connectDB();
		if ($type == 'id') {
			$stmt = $DBH->prepare("SELECT * FROM adm_server WHERE adm_id = :id");
		} elseif ($type == 'type') {
			$stmt = $DBH->prepare("SELECT * FROM adm_server WHERE adm_type = :type");
		}
		$stmt->execute([':type' => $admId]);

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
			
		return $result;
	}
	

	
	

	public static function test(){
		return 'GO51'; 
	}
}
?>