<?php
namespace classes;

use ZipArchive; //Включили пространство имен для ZipArchive
use RecursiveIteratorIterator;
use RecursiveDirectoryIterator;
// Не нужно использовать PDO, если мы не работаем с базой данных в этом классе


class Backup { //Исправили на правильное название класса

    public static function backupFile(): string { // Добавили тип возвращаемого значения
        $sourceDir = $_SERVER['DOCUMENT_ROOT']; // Путь к директории, которую нужно резервировать
        $backupDir = $_SERVER['DOCUMENT_ROOT'] . '/backup/'; // Путь к директории для резервных копий
        $backupFilename = 'backup_' . date('Y-m-d_H-i-s') . '.zip'; // Имя файла резервной копии

        // Проверка существования исходной директории
        if (!is_dir($sourceDir)) {
            throw new \Exception("Ошибка: исходная директория '$sourceDir' не найдена."); //Исключение вместо die
        }

        // Проверка и создание директории для резервных копий
        if (!is_dir($backupDir)) {
            if (!mkdir($backupDir, 0755, true)) { // Создаем директорию, если ее нет, 0755 - права доступа
                throw new \Exception("Ошибка: не удалось создать директорию для резервных копий '$backupDir'."); //Исключение вместо die
            }
        }

        // Полный путь к файлу резервной копии
        $backupFilepath = $backupDir . '/' . $backupFilename;

        // Создание архива zip
        $zip = new ZipArchive();
        if ($zip->open($backupFilepath, ZipArchive::CREATE) !== true) {
            throw new \Exception("Ошибка: не удалось создать архив: " . $zip->getStatusString()); //Исключение вместо die, добавлено получение сообщения об ошибке
        }

        // Добавление файлов в архив -  улучшенная обработка исключений
        try {
            $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($sourceDir));
            foreach ($files as $file) {
                if ($file->isFile()) {
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen($sourceDir) + 1); // Относительный путь внутри архива
                    if (!$zip->addFile($filePath, $relativePath)) {
                        throw new \Exception("Ошибка при добавлении файла '$filePath' в архив.");
                    }
                }
            }
        } catch (\Exception $e) {
            $zip->close(); //Закрываем архив перед выбрасыванием исключения
            throw new \Exception("Ошибка при архивации файлов: " . $e->getMessage());
        }

        // Закрытие архива
        if (!$zip->close()) {
            throw new \Exception("Ошибка: не удалось закрыть архив."); //Исключение вместо die
        }

        return $backupFilepath; // Возвращаем путь к созданному архиву
    }

    public static function test(): string { // Добавили тип возвращаемого значения
        return 'GO51';
    }
}
?>

