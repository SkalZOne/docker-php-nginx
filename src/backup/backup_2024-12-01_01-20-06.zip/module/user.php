<?
namespace classes;

use PDO; 

class user{
	
	/* Проверка авторизованн ли пользователь */
	public static function isAuthorize(){
		if( isset($_SESSION['user_id']) ){
			return true;
		}else{
			return false;
		}
	}
	
		
	/* Авторизации */
	public static function login(array $arr) {
        $DBH = core::connectDB();
		
		$ip = $_SERVER['REMOTE_ADDR'];
        $user_agent = $_SERVER['HTTP_USER_AGENT'];

        // Валидация данных
        $login = isset($arr['login']) ? trim($arr['login']) : '';
        $password = isset($arr['password']) ? trim($arr['password']) : '';

        if( empty($login) || empty($password) ) {
            return "Логин и пароль должны быть заполнены.";
			self::logLoginAttempt($arr, $login, $ip, $user_agent, 1, null, $DBH);
        }

        if( !ctype_alnum($login) ) {
            return "Логин может содержать только буквы и цифры.";
			self::logLoginAttempt($arr, $login, $ip, $user_agent, 1, null, $DBH);
        }

        if( strlen($password) < 6 ) {
			self::logLoginAttempt($arr, $login, $ip, $user_agent, 1, null, $DBH);
            return "Пароль должен быть не менее 6 символов.";
        }
 

		$stmt = $DBH->prepare("SELECT COUNT(*) FROM adm_user_log_login WHERE (adm_ip = :ip OR adm_user_login = :login) AND adm_date >= DATE_SUB(NOW(), INTERVAL 15 MINUTE) AND adm_status > 0");
		$stmt->execute([':ip' => $ip, ':login' => $login]);
		$attempts = $stmt->fetchColumn();
		if ($attempts >= 5) {
			self::logLoginAttempt($arr, $login, $ip, $user_agent, 3, null, $DBH);
			return "Слишком много попыток входа. Попробуйте позже.";
		}

		$csrf_token = $arr['csrf_token'] ?? '';
		if( !isset($_SESSION['csrf_token']) || $csrf_token !== $_SESSION['csrf_token'] ) {
			return "Ошибка авторизации.";
			self::logLoginAttempt($arr, $login, $ip, $user_agent, 2, null, $DBH);
		}
		unset($_SESSION['csrf_token']);

        try{
            $stmt = $DBH->prepare("SELECT * FROM adm_user WHERE adm_login = :login");
            $stmt->bindParam(':login', $login);
            $stmt->execute();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if( $result && password_verify($password, $result['adm_password']) ){
                $_SESSION['user_id'] = $result['adm_id'];
                $_SESSION['user_login'] = $result['adm_login'];
				self::logLoginAttempt($arr, $login, $ip, $user_agent, 0, null, $DBH);
                return true;
            }else{
				self::logLoginAttempt($arr, $login, $ip, $user_agent, 2, null, $DBH);
                return "Неверный логин или пароль.";
            }
        }catch(PDOException $e){
			self::logLoginAttempt($arr, $login, $ip, $user_agent, 4, null, $DBH);
			return "Ошибка авторизации.";
        }
    }
	
	//выход
    public static function logout(){
        session_unset(); //  Очищаем все переменные сессии
        session_destroy(); //  Уничтожаем сессию
        //  Можно  добавить  редирект  на  страницу  авторизации:

        header("Location: /login.php");  // Или  на  главную  страницу
        exit;
    }
	
	//логирование авторизации
	protected static function logLoginAttempt(array $post, string $user_login, string $ip, string $user_agent, int $status, ?int $user_id, \PDO $DBH){
        //0 - успешная авторизация
		//1 - неправильно заполнена форма
		//2 - неправильные данные
		//3 - подозрение брут
		//4 - проблемы сервера
		$stmt = $DBH->prepare("INSERT INTO adm_user_log_login 
			(adm_user_login, adm_ip, adm_status, adm_user_agent, adm_post) 
				VALUES 
			(:user_login, :ip, :status, :user_agent, :post)");

        $stmt->execute([
            ':user_login' => $user_login,
            ':ip' => $ip,
            ':status' => $status,
            ':user_agent' => $user_agent,
            ':post' => json_encode($post)
        ]);

    }
}
?>