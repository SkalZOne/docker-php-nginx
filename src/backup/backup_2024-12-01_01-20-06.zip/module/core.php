<?
namespace classes;

use PDO;

class core{
	
	//конект к базе данных админ. панели
	public static function connectDB(){
		global $DBH;
		if(!$DBH){
			$host = 'localhost';
			$dbname = 'infoaqtl_adm';
			$user = 'infoaqtl_adm';
			$pass = '0xFlK&sQ!csp';
			$DBH = new PDO("mysql:host=$host;dbname=$dbname;charset=UTF8", $user, $pass, [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ]);
			// echo '~con~';
			return $DBH;
		}else{
			return $DBH;
		}
	}
	
	//конект к сторонней базе данных
	public static function other_connectDB($admId, $arr = false){
		global $ODBH;
		if (!isset($ODBH[$admId]) || !$ODBH[$admId] instanceof PDO) {
			if( !is_array($arr) ){
				$arr = self::getContentById($admId, true);
			}
			$host = $arr['adm_server'];
			$dbname = $arr['adm_name'];
			$user = $arr['adm_user'];
			$pass = $arr['adm_password'];
			$ODBH[$admId] = new PDO("mysql:host=$host;dbname=$dbname;charset=UTF8", $user, $pass, [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ]);
			return $ODBH[$admId];
		}else{
			return $ODBH[$admId];
		}
	}
	
	//подключение по FTP
	public static function connectFTP($admId, $arr = false){
		global $FTP;
		if( !isset($FTP[$admId]) ) {
			
			$arr = is_array($arr) ? $arr : self::getFTP($admId, 'id', true);
			
			$ftp_server = $arr[$admId]['adm_server'];
			$ftp_user = $arr[$admId]['adm_name'];
			$ftp_pass = $arr[$admId]['adm_password'];
			$conn_id = ftp_connect($ftp_server);
			if (!$conn_id) {
				return false;
			}
			$login_result = ftp_login($conn_id, $ftp_user, $ftp_pass);
			ftp_pasv($conn_id, true);
			if (!$login_result) {
				ftp_close($conn_id);
				return false;
			}
			$FTP[$admId] = $conn_id;
			return $FTP[$admId];
		}else{
			return $FTP[$admId];
		}
		
	}
	
	//получить данные сервера OLD***OLD***OLD***OLD***OLD***OLD***OLD***OLD***OLD***OLD
	public static function getServer($admId, $type = 'id'){
		$DBH = self::connectDB();
		if ($type == 'id') {
			$stmt = $DBH->prepare("SELECT * FROM adm_server WHERE adm_id = :id");
		} elseif ($type == 'type') {
			$stmt = $DBH->prepare("SELECT * FROM adm_server WHERE adm_type = :type");
		}
		$stmt->execute([':type' => $admId]);

		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
			
		return $result;
	}
	
	//создание токена для формы логина
	public static function generateCSRFToken(){
		return bin2hex(random_bytes(32));
	}
	
	//шифрование данных !УБАРТЬ КЛЮЧ ПОСЛЕ ТЕСТИРОВАНИЯ
	public static function encryptData(string $data, string $key = 'IBcI4HpoZI0EPRTV', string $method = 'aes-256-cbc'){
		$ivlen = openssl_cipher_iv_length($method);
		$iv = openssl_random_pseudo_bytes($ivlen);
		$ciphertext_raw = openssl_encrypt($data, $method, $key, OPENSSL_RAW_DATA, $iv);
		$hmac = hash_hmac('sha256', $ciphertext_raw, $key, true);
		$encrypted = base64_encode($iv . $hmac . $ciphertext_raw);
		return "CRY_" . $encrypted;
	}
	
	//дешифрование данных !УБАРТЬ КЛЮЧ ПОСЛЕ ТЕСТИРОВАНИЯ
	public static function decryptData(string $data, string $key = 'IBcI4HpoZI0EPRTV', string $method = 'aes-256-cbc'){
		if( strpos($data, 'CRY_') === 0 ) {
			$data = substr($data, 4); // Удаляем префикс "CRY_"
			$c = base64_decode($data);
			$ivlen = openssl_cipher_iv_length($method);
			$iv = substr($c, 0, $ivlen);
			$hmac = substr($c, $ivlen, $sha2len = 32);
			$ciphertext_raw = substr($c, $ivlen + $sha2len);
			$original_plaintext = openssl_decrypt($ciphertext_raw, $method, $key, OPENSSL_RAW_DATA, $iv);

			$calcmac = hash_hmac('sha256', $ciphertext_raw, $key, true);

			if( hash_equals($hmac, $calcmac) ){
				return $original_plaintext;
			}
		}
		return $data; // Возвращаем исходную строку, если она не зашифрована (не начинается с CRY_)
	}

	//уникальный код
	public static function encode_number_crc32($number) {
		$hashed = hash('crc32', $number);
		$encoded = base_convert($hashed, 16, 36);
		return $encoded;
	}

	//получить данные для подключения к бд
	public static function getContentById(int $admId, bool $decrypt = false){
		$DBH = self::connectDB();
		$stmt = $DBH->prepare("SELECT ac.*, adb.* FROM adm_content ac INNER JOIN adm_db adb ON ac.adm_db_id = adb.adm_id WHERE ac.adm_id = :admId");
		$stmt->execute([':admId' => $admId]);
		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		if($result && $decrypt){
			foreach($result as $code => &$value){
				$value = self::decryptData($value);
			}
		}
		return $result ?: false;
	}
	
	//получить данные ftp
	public static function getFTP($admId, $type = 'id', bool $decrypt = false) {
		$DBH = self::connectDB();
		if ($type == 'id') {
			$stmt = $DBH->prepare("SELECT * FROM adm_ftp WHERE adm_id = :id");
		} elseif ($type == 'type') {
			$stmt = $DBH->prepare("SELECT * FROM adm_ftp WHERE adm_type = :id");
		}
		$stmt->execute([':id' => $admId]);

		$result = [];
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$id = $row['adm_id']; // Извлекаем adm_id

			if ($decrypt) {
				$row = array_map([self::class, 'decryptData'], $row);
			}

			$result[$id] = $row; // Используем adm_id как ключ
		}

		return $result ?: false;
	}
	
	//данные для типа файлов
	public static function getMIME($value, $type = 'id', ) {
		$DBH = self::connectDB();
		$result = [];
		if( $type == 'id' ){
			// $stmt = $DBH->prepare("SELECT * FROM adm_ftp WHERE adm_id = :id");
		}elseif( $type == 'module' ) {
			$stmt = $DBH->prepare("SELECT
										adm_mime.adm_id,
										adm_mime.adm_name,
										adm_mime.adm_extension,
										adm_mime.adm_type_id,
										adm_mime_module.adm_text,
										adm_mime_module.adm_allowed
									FROM
										adm_mime_module
									JOIN
										adm_mime ON adm_mime_module.adm_mime_id = adm_mime.adm_id
									WHERE
										adm_mime_module.adm_module_name = :name");
			$stmt->execute([':name' => $value]);
		}
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		foreach( $row as $value){
			$result[$value['adm_name']] = $value;
		}
		
		
		return $result;
	}
	
	
	
	
	
	
	
	
	
	
	
	/* public static function getFTP($admId, $type = 'id', bool $decrypt = false){
		$DBH = self::connectDB();
		if( $type == 'id' ){
			$stmt = $DBH->prepare("SELECT * FROM adm_ftp WHERE adm_id = :id");
		}elseif( $type == 'type' ){
			$stmt = $DBH->prepare("SELECT * FROM adm_ftp WHERE adm_type = :id");
		}
		$stmt->execute([':id' => $admId]);
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if($result && $decrypt){
			foreach($result as &$value){
				$value = self::decryptData($value);
			}
		}
		return $result ?: false;
	} */
	
	
	

	public static function test(){
		return 'GO51'; 
	}
}
?>