<?
$arr = classes\media::getAllMedia();
?>

<div class="media-container">
	<div class="media-section">
		<?$sectionIndex = 0;?>
		<?foreach( $arr as $code=>$value ){?>
			<div section-id="<?=$code?>" class="media-section-item <?=($sectionIndex==0)?'active':'';?>"><?=$value['name']?></div>
			<?$sectionIndex++;?>
		<?}?>
	</div>
	<div class="media-images">
		<?$sectorIndex = 0;?>

		<?foreach( $arr as $section_key => $section ){?>
			<div class="media-image-sector <?=($sectorIndex==0)?'active':'';?>" section-id="<?=$section_key?>">

				<?$pageIndex = 0;?>

				<?foreach( $section['item'] as $page => $items ){?>
					<div class="media-image-page row <?=($pageIndex==0)?'active':'';?>" page-index="<?=$page?>">
						<?foreach($items as $item){?>
							<div class="media-img-item col-auto">
								<img src="<?=$item['adm_src']?>" alt="">
								<div class="media-img-desc"><?=$item['adm_description']?></div>
							</div>
						<?}?>
					</div>
				<?}?>

				<div class="media-images-pagination">
					<?foreach( $section['item'] as $pageNumber => $items ){?>
						<div class="media-img-page-btn <?=($pageIndex==0)?'active':'';?>"><?=$pageNumber?></div>
					<?}?>
				</div>

				<?$pageIndex++;?>
			</div>

			<?$sectorIndex++;?>
		<?}?>

	</div>
</div>

<style>
	.media-container {
		display: flex;
		background-color: #fff;
		padding: 0.5rem;
	}
	/* section block */
	.media-section {
		margin-right: 3rem;
	}	
	.media-section-item {
		transition: 0.2s;
		cursor: pointer;
		margin-bottom: 0.5rem;
		padding: 0.5rem;
	}
	.media-section-item:hover {
		background-color: rgba(0, 0, 0, 0.1);
	}
	.media-section-item.active {
		background-color: rgba(0, 0, 0, 0.05);
	}
	/* section block */

	/* images block */
	.media-image-sector{
		display: none;
	}
	.media-image-sector.active {
		display: block;
	}

	.media-image-page {
		display: none;
		max-width: 100%;
	}
	.media-image-page.active {
		display: flex;
	}

	.media-img-item {
		padding: 0.5rem;
		border: 1px solid rgba(0, 0, 0, 0.6);
		cursor: pointer;
	}
	.media-img-item:hover {
		transition: 0.2s;
		background-color: rgba(0, 0, 0, 0.05);
	}
	.media-img-item img {
		width: 100px;
		height: 100px;
		object-fit: contain;
	}

	.media-images-pagination {
		display: flex;
		margin-top: 3rem;
	}
	.media-img-page-btn {
		width: 50px;
		height: 50px;
		border: 1px solid rgba(0, 0, 0, 0.1);
		display: flex;
		align-items: center;
		justify-content: center;
		cursor: pointer;
		transition: 0.2s;
	}
	.media-img-page-btn.active {
		background-color: rgba(0, 0, 0, 0.05);
	}
	.media-img-page-btn:hover {
		background-color: rgba(0, 0, 0, 0.1);
	}
	/* images block */
</style>

<script>
	$(document).ready(function(){
		$('.media-section-item').on('click', function(event){
			let target = $(event.target);

			$('.media-section-item.active').removeClass('active');
			target.addClass('active');

			$('.media-image-sector.active').removeClass('active');
			$('.media-image-sector[section-id="' + target.attr('section-id') + '"]').addClass('active');
		});

		$('.media-img-page-btn').on('click', function(event) {
			let target = $(event.target);

			$('.media-img-page-btn.active').removeClass('active');
			target.addClass('active');

			$('.media-image-page.active').removeClass('active');
			$('.media-image-page[page-index="' + target.text() + '"').addClass('active');
		});
	});
</script>