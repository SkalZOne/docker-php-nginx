<script src="/assets/lib/jquery/jquery.js"></script>

<script src="/assets/lib/jquery/resizable.min.js"></script>
<link href="/assets/lib/jquery/resizable.min.css" rel="stylesheet">

<script src="/assets/lib/jquery/raphael-min.js"></script>
<script src="/assets/lib/jquery/morris.min.js"></script>
<link href="/assets/lib/jquery/morris.css" rel="stylesheet">

<link href="/assets/lib/text-editor/fa.min.css" rel="stylesheet">
<script src="/assets/lib/text-editor/scripts.js"></script>
<link href="/assets/lib/text-editor/style.css" rel="stylesheet">

<link href="/assets/lib/bootstrap/style.css" rel="stylesheet">
<script src="/assets/lib/bootstrap/script.js"></script>
<link href="/assets/css/main.css" rel="stylesheet">
<script src="/assets/js/main.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<meta http-equiv="X-UA-Compatible" content="ie=edge">