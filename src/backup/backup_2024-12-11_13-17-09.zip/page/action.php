<?
if( isset($_POST['form']['teh_classes']) && isset($_POST['form']['teh_function']) && 
	isset($_POST['form']['teh_action']) && $_POST['form']['teh_action'] == 'Y' &&
	(( isset($_REQUEST['form_action']) && $_REQUEST['form_action'] != 'N' ) || !isset($_REQUEST['form_action']) ) ){

	$function = $_POST['form']['teh_function'];
	$classes = 'classes\\'.$_POST['form']['teh_classes'];
	$result = $classes::$function();
	if( $result['type'] == 'error' ){
		
	}elseif( $result['type'] == 'redirect' ){
		header('Location: '.$result['url']);
	}
}
?>