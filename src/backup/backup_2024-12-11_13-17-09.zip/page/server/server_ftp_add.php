<?
$FTPServerTypes = classes\server::getFTPServerTypes();
?>


<form action="" method="POST">	
    <input type="hidden" name="form[teh_action]" value="Y" />
    <input type="hidden" name="form[teh_function]" value="addServerAccess" />
    <input type="hidden" name="form[teh_classes]" value="server" />
    <input type="hidden" name="form[teh_server_type]" value="ftp" />
    <div class="adm-detail">
        <div class="tab-content">
            <div class="tabs">
                <div class="tab-btn active" data-tab="tab1">Добавить</div>
            </div>

            <table class="adm-table tab1" id="tab1">
                <tr class="heading">
                    <td colspan="2"><strong>Добавить доступ</strong></td>
                </tr>

                <tr>
                    <td class="adm-detail-content-cell-l"><strong>Название:</strong></td>
                    <td>
                        <input type="text" style="width: 75%" name="form[adm_name]" value="">
                    </td>
                </tr>

                <tr>
                    <td class="adm-detail-content-cell-l"><strong>Пароль:</strong></td>
                    <td>
                        <input type="text" style="width: 75%" name="form[adm_password]" value="">
                    </td>
                </tr>

                <tr>
                    <td class="adm-detail-content-cell-l"><strong>Сервер:</strong></td>
                    <td>
                        <input type="text" style="width: 75%" name="form[adm_server]" value="">
                    </td>
                </tr>

                <tr>
                    <td class="adm-detail-content-cell-l"><strong>Тип:</strong></td>
                    <td>
                        <select name="form[adm_type]" size="5">
                            <?foreach( $FTPServerTypes as $key => $value ) {?>
                                <option value="<?=$key?>"><?=$value?></option>
                            <?}?>
                        </select>
                    </td>
                </tr>
            </table>   

            <div class="adm-detail-footer">
                <input type="submit" name="action" class="adm-detail-but1" value="Сохранить">
                <a href="#" class="adm-detail-but2" >Отменить</a>
            </div>
    </div>
</form>