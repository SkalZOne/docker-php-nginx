<?
namespace classes;

use PDO;

/**/

class content{
	
	//получаем список контентных блоков
	public static function getContentList(){
		$DBH = core::connectDB();
		$result = [];
		try { 
			$stmt = $DBH->prepare("SELECT * FROM `adm_content`");
			$stmt->execute();
			$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
			foreach( $row as $value ){
				$result[$value['adm_id']] = $value;
			}
			return $result;
		} catch (PDOException $e) {
			error_log("Ошибка выполнения запроса: " . $e->getMessage());
			return false;
		}
	}
	
	
	
	//получаем разделы
	//	type
	//		all - все
	//		id - один по ид
	//		all_tree - все в виде дерева
	//		id_tree - дерево связанных элементов (не сделанно)
	private static $getSectionCache = [];
	public static function getSection($admId, $type = 'all', $id = null) {
		$cacheKey = "{$admId}" . ($type == 'id' ? "_{$id}" : "");
		
		if( $type == 'id' && !isset($id) )
			return false;
			
		if( isset(self::$getSectionCache[$cacheKey]) ){
			$result = self::$getSectionCache[$cacheKey];
        }elseif( isset(self::$getSectionCache[$admId]) && $type == 'id' ){
			$row = self::$getSectionCache[$admId];
			foreach( $row as $value ){
				if( $value['pr_id'] == $id )
					$result = $value;
			}
			
        }else{
			$arr = core::getContentById($admId, true);
			$ODBH[$admId] = core::other_connectDB($admId, $arr);
			if (!$ODBH[$admId]) {
				return false;
			}
			if ($type == 'id') {
				$stmt = $ODBH[$admId]->prepare("SELECT * FROM `pr_section` WHERE `pr_id` = :id");
				$stmt->bindValue(':id', $id, PDO::PARAM_INT); 
				$stmt->execute();
				$result = $stmt->fetch(PDO::FETCH_ASSOC);
			} else {
				$stmt = $ODBH[$admId]->prepare("SELECT * FROM `pr_section`");
				$stmt->execute();
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
			}
			self::$getSectionCache[$cacheKey] = $result;
		}
		
		if ($type == 'all_tree') {
			$result = self::SectionBuildTree($result);
		}	
		
		return $result;
	}
	
			//формирования дерева секций
			public static function SectionBuildTree(array $data, int $parentId = 0): array {
				$tree = [];
				foreach( $data as $item ){
					if ($item['pr_parent_id'] == $parentId) {
						$item['items'] = self::SectionBuildTree($data, $item['pr_id']);
						$tree[] = $item;
					}
				}
				return $tree;
			}

			//получить из getSection первые дочерние элементы
			public static function filterTreeChildById($admId, $startId){
				$tree = self::getSection($admId);
				$filteredTree = array_filter($tree, function ($item) use ($startId) {
					return $item['pr_parent_id'] == $startId;
				});
				return array_values($filteredTree);
			}
			
			//получить хлебные крошки
			public static function getBreadcrumbs($admId, $target_pr_id) {
				$breadcrumbs = [];	
				if( isset($target_pr_id) && $target_pr_id != 0 && $target_pr_id != '' ){
					$arr = self::getSection($admId);
					$current_pr_id = $target_pr_id;
					$i = 0;
					while($current_pr_id != 0){
						$i++;
						$found = false;
						foreach($arr as $item){   
							if($item['pr_id'] == $current_pr_id){
								$breadcrumbs[] = $item;
								$current_pr_id = $item['pr_parent_id'];
								$found = true;
								break;
							}
						}
						if($i > 200){$current_pr_id = 0;}
					}
				}

				return array_reverse($breadcrumbs);
			}
			
			//вывод дерева разделов OPTION 
			public static function buildTreeOptions($tree, $selected = null, $level = 0) {
				$options = '';
				foreach ($tree as $item) {
					$prefix = str_repeat('- ', $level);
					$sel = (isset($selected) && (in_array($item['pr_id'], (array)$selected))) ? 'selected' : '';
					$options .= "<option value=\"{$item['pr_id']}\" {$sel}>{$prefix}{$item['pr_name']}</option>";
					if( isset($item['items']) && is_array($item['items']) ){
						$options .= self::buildTreeOptions($item['items'], $selected, $level + 1);
					}
				}
				return $options;
			}
		
		//получаем свойства для разделов
		public static function getSectionProperty($admId, $sectionId = null){
			$arr = core::getContentById($admId, true);
			$ODBH[$admId] = core::other_connectDB($admId, $arr);
			$detailSql = '';
			if (!$ODBH[$admId]) {
				return false;
			}
			if( $sectionId )
				$detailSql = "LEFT JOIN `pr_section_value` ON 
								`pr_section_property`.`pr_id` = `pr_section_value`.`pr_property_id` AND 
								`pr_section_value`.`pr_section_id` = :id";
								
			$sql = "SELECT 
						`pr_section_property`.`pr_id`,
						`pr_section_property`.`pr_name`,
						`pr_section_property`.`pr_type`,
						`pr_section_property`.`pr_multiple`,
						`pr_section_property_tab`.`pr_id` AS `pr_tab_id`,
						`pr_section_property_tab`.`pr_name` AS `pr_tab_name`,
						`pr_section_property_value`.`pr_id` AS `pr_value_id`,
						`pr_section_property_value`.`pr_value` AS `pr_value_value`
						" . ($sectionId ? ",`pr_section_value`.`pr_value`" : "") . "
					FROM 
						`pr_section_property`
						LEFT JOIN `pr_section_property_tab` ON `pr_section_property`.`pr_tab` = `pr_section_property_tab`.`pr_id`
						LEFT JOIN `pr_section_property_value` ON `pr_section_property`.`pr_id` = `pr_section_property_value`.`pr_property_id`
						{$detailSql}
					ORDER BY `pr_section_property_tab`.`pr_sort` ASC,
							 `pr_section_property`.`pr_sort` ASC
					";
					
			$stmt = $ODBH[$admId]->prepare($sql);
			if( $sectionId )
				$stmt->bindValue(':id', $sectionId);
			$stmt->execute();
			$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
			
			foreach( $row as $value ){
				$result[$value['pr_tab_id']]['name'] = $value['pr_tab_name'];
				if( !isset($result[$value['pr_tab_id']]['item'][$value['pr_id']]) ){
					$result[$value['pr_tab_id']]['item'][$value['pr_id']] = $value;
				}
				if( $value['pr_multiple'] != '0' && isset($result[$value['pr_tab_id']]['item'][$value['pr_id']]['pr_value']) ){
					if( !is_array($result[$value['pr_tab_id']]['item'][$value['pr_id']]['pr_value']) )
						unset($result[$value['pr_tab_id']]['item'][$value['pr_id']]['pr_value']);
					if( $value['pr_type'] == '3' || $value['pr_type'] == '4' ){
						$result[$value['pr_tab_id']]['item'][$value['pr_id']]['pr_value'][$value['pr_value']] = $value['pr_value'];
					}else{
						$result[$value['pr_tab_id']]['item'][$value['pr_id']]['pr_value'][] = $value['pr_value'];
					}
				}
				if( $value['pr_value_value'] != '' ){
					$result[$value['pr_tab_id']]['item'][$value['pr_id']]['items'][$value['pr_value_id']] = $value['pr_value_value'];
				}
			}
			
			
			return $result;
		}
		
		
		//НЕЙРОНКА НАПИСАЛА С ОШИБКОЙ
		public static function filterTreeByStartId(array $tree, int $startId): array {
			$filteredTree = [];
			$findAndAdd = function(array &$tree, int $startId, bool &$found) use (&$findAndAdd, &$filteredTree) {
				foreach ($tree as $key => &$item){
					if( $found || $item['pr_id'] == $startId ){
						$filteredTree[] = $item;
						$found = true;
					}
					if( !empty($item['items']) ){
						$findAndAdd($item['items'], $startId, $found);
					}
					if( !$found ){
						unset($tree[$key]);
					}
				}
			};
			$found = false;
			$findAndAdd($tree, $startId, $found);
			return $filteredTree;
		}
		

	//добавление нового раздела
	public static function addSection() {
		$arr = $_POST['form'];
		$ODBH[$arr['teh_content_id']] = core::other_connectDB($arr['teh_content_id']);
		
		$pr_name = $arr['pr_name'] ?? null;
		$pr_code = $arr['pr_code'] ?? null;
		$pr_parent_id = $arr['pr_parent_id'] ?? 0;
		$pr_sort = $arr['pr_sort'] ?? null;
		$pr_action = $arr['pr_action'] ?? 0;
		
		if( !preg_match('/^[a-zA-Z0-9_-]+$/', $pr_code) ){
			return 'error';
		}
		
		if ($pr_name === null || $pr_code === null ) {
			// $error = 'Не заполнены обязательные поля';
			// return '/content/?content='.$arr['teh_content_id'].'&error='.urlencode($error);
			return 'error';
		} 
		
 		try {
			$sql = "INSERT INTO `pr_section` 
						(`pr_name`, `pr_code`, `pr_parent_id`, `pr_sort`, `pr_action`) 
					VALUES 
						(:pr_name, :pr_code, :pr_parent_id, :pr_sort, :pr_action)";
			$stmt = $ODBH[$arr['teh_content_id']]->prepare($sql); 
			$stmt->execute([
				':pr_name' => $pr_name,
				':pr_code' => $pr_code,
				':pr_parent_id' => $pr_parent_id,
				':pr_sort' => $pr_sort,
				':pr_action' => $pr_action,
			]);
			$newId = $ODBH[$arr['teh_content_id']]->lastInsertId();
			
			
			$ODBH[$arr['teh_content_id']]->beginTransaction();
			$stmt = $ODBH[$arr['teh_content_id']]->prepare("INSERT INTO `pr_section_value`(`pr_section_id`, `pr_property_id`, `pr_value`) VALUES (?, ?, ?)");
			$data = [];
			foreach( $arr['prop'] as $code => $value ){
				$values = is_array($value) ? $value : [$value];
				foreach( $values as $v ) {
					if( isset($v) && $v != '' )
						$stmt->execute([$newId, $code, $v]);
				}
			}
			$ODBH[$arr['teh_content_id']]->commit();
			
			$res['type'] = 'redirect';
			$res['url'] = '/content/section.php?content='.$arr['teh_content_id'].'&id='.$newId;;
			
			return $res;
		} catch (PDOException $e) {
			$ODBH[$arr['teh_content_id']]->rollBack();
			return "Ошибка при добавлении секции: " . $e->getMessage();
		}
	}
	
	public static function updateSection(){
		$arr = $_POST['form'];
		
		$pr_name = $arr['pr_name'] ?? null;
		$pr_code = $arr['pr_code'] ?? null;
		$pr_parent_id = $arr['pr_parent_id'] ?? 0;
		$pr_sort = $arr['pr_sort'] ?? null;
		$pr_action = $arr['pr_action'] ?? 0;
		
		$ODBH[$arr['teh_content_id']] = core::other_connectDB($arr['teh_content_id']);

		$newData = $_POST['form']['prop'];
		$oldData = $_POST['oldform']['prop'];
		$sectionId = $_POST['form']['id'];
		
		
		$sql = "UPDATE pr_section SET 
					pr_name = :pr_name, pr_code = :pr_code, pr_parent_id = :pr_parent_id, 
					pr_sort = :pr_sort, pr_action = :pr_action WHERE pr_id = :pr_id";
		$stmt = $ODBH[$arr['teh_content_id']]->prepare($sql); 
		$stmt->execute([
			':pr_id' => $sectionId,
			':pr_name' => $pr_name,
			':pr_code' => $pr_code,
			':pr_parent_id' => $pr_parent_id,
			':pr_sort' => $pr_sort,
			':pr_action' => $pr_action,
		]);
		
		$ODBH[$arr['teh_content_id']]->beginTransaction();
		
		foreach($newData as $propertyId => $newValues) {
			$oldValues = isset($oldData[$propertyId]) ? $oldData[$propertyId] : []; // значения по умолчанию
			if (is_array($newValues)) {
				$valuesToAdd = array_diff($newValues, $oldValues);
				$valuesToDelete = array_diff($oldValues, $newValues);
	
				foreach ($valuesToDelete as $valueToDelete) {
				  $stmt = $ODBH[$arr['teh_content_id']]->prepare("DELETE FROM pr_section_value WHERE pr_section_id = :section_id AND pr_property_id = :property_id AND pr_value = :value");
				  $stmt->execute([':section_id' => $sectionId, ':property_id' => $propertyId, ':value' => $valueToDelete]);
				}
				
				foreach ($valuesToAdd as $valueToAdd) {
				  $stmt = $ODBH[$arr['teh_content_id']]->prepare("INSERT INTO pr_section_value (pr_section_id, pr_property_id, pr_value) VALUES (:section_id, :property_id, :value)");
				  $stmt->execute([':section_id' => $sectionId, ':property_id' => $propertyId, ':value' => $valueToAdd]);
				}	
			}else{
				if( isset($oldData[$propertyId]) && $oldData[$propertyId] != '' && $newValues != '' && $newValues != $oldData[$propertyId] ){
					$updateStmt = $ODBH[$arr['teh_content_id']]->prepare("UPDATE pr_section_value SET pr_value = :value WHERE pr_section_id = :section_id AND pr_property_id = :property_id");
					$updateStmt->execute([':section_id' => $sectionId, ':property_id' => $propertyId, ':value' => $newValues]);
				}elseif( isset($oldData[$propertyId]) && $newValues == '' ){
					$deleteStmt = $ODBH[$arr['teh_content_id']]->prepare("DELETE FROM `pr_section_value` WHERE pr_section_id = :section_id AND pr_property_id = :property_id");
					$deleteStmt->execute([':section_id' => $sectionId, ':property_id' => $propertyId]);
				}elseif( $oldData[$propertyId] == '' && $newValues != '' ){
					$insertStmt = $ODBH[$arr['teh_content_id']]->prepare("INSERT INTO pr_section_value (pr_section_id, pr_property_id, pr_value) VALUES (:section_id, :property_id, :value)");
					$insertStmt->execute([':section_id' => $sectionId, ':property_id' => $propertyId, ':value' => $newValues]);
				}
			}
		}
		
		foreach ($oldData as $propertyId => $oldValues) {
			if (!array_key_exists($propertyId, $newData)) {
				$deleteStmt = $ODBH[$arr['teh_content_id']]->prepare("DELETE FROM pr_section_value WHERE pr_section_id = :section_id AND pr_property_id = :property_id");
				$deleteStmt->execute([':section_id' => $sectionId, ':property_id' => $propertyId]);
			}
		}
		
		$ODBH[$arr['teh_content_id']]->commit();
	}





	/* РАБОТА С ЭЛЕПМЕНТАМИ */
	
	public static function getElementList($admId, $admSectionId = null){
		$arr = core::getContentById($admId, true);
		$ODBH[$admId] = core::other_connectDB($admId, $arr);
		if (!$ODBH[$admId]) {
			return false;
		}
		
		if ( $admSectionId ) {
			$stmt = $ODBH[$admId]->prepare("SELECT *
											FROM pr_element pe
											WHERE EXISTS (
												SELECT 1
												FROM pr_section_to pst
												WHERE pst.pr_element = pe.pr_id AND pst.pr_section = :id
											);");
			$stmt->bindValue(':id', $admSectionId, PDO::PARAM_INT);
			$stmt->execute();
			$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
			
		} else {
			$stmt = $ODBH[$admId]->prepare("SELECT * FROM pr_element");
			$stmt->execute();
			$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		}
		
		return $result;
	}
	
	public static function getElement($admId, $elementId){
		$arr = core::getContentById($admId, true);
		$ODBH[$admId] = core::other_connectDB($admId, $arr);
		if (!$ODBH[$admId]) {
			return false;
		}
	
		$stmt = $ODBH[$admId]->prepare("SELECT * FROM pr_element 
											LEFT JOIN pr_section_to ON pr_section_to.pr_element = pr_element.pr_id
											WHERE pr_element.pr_id = :id
											");
		$stmt->bindValue(':id', $elementId, PDO::PARAM_INT);
		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);
			
		
		return $result;
	}

	public static function getElementProperty($admId, $elementId = null, $type = 'tab'){
		$arr = core::getContentById($admId, true);
		$ODBH[$admId] = core::other_connectDB($admId, $arr);
		$detailSql = '';
		if (!$ODBH[$admId]) {
			return false;
		}
		if( $elementId )
			$detailSql = "LEFT JOIN `pr_element_value` ON 
							`pr_element_property`.`pr_id` = `pr_element_value`.`pr_property_id` AND 
							`pr_element_value`.`pr_element_id` = :id";
							
		$sql = "SELECT 
					`pr_element_property`.`pr_id`,
					`pr_element_property`.`pr_name`,
					`pr_element_property`.`pr_type`,
					`pr_element_property`.`pr_multiple`,
					`pr_element_property_tab`.`pr_id` AS `pr_tab_id`,
					`pr_element_property_tab`.`pr_name` AS `pr_tab_name`,
					`pr_element_property_value`.`pr_id` AS `pr_value_id`,
					`pr_element_property_value`.`pr_value` AS `pr_value_value`
					" . ($elementId ? ",`pr_element_value`.`pr_value`" : "") . "
				FROM 
					`pr_element_property`
					LEFT JOIN `pr_element_property_tab` ON `pr_element_property`.`pr_tab` = `pr_element_property_tab`.`pr_id`
					LEFT JOIN `pr_element_property_value` ON `pr_element_property`.`pr_id` = `pr_element_property_value`.`pr_property_id`
					{$detailSql}
				ORDER BY `pr_element_property_tab`.`pr_sort` ASC,
						 `pr_element_property`.`pr_sort` ASC
				";
				
		$stmt = $ODBH[$admId]->prepare($sql);
		if( $elementId )
			$stmt->bindValue(':id', $elementId);
		$stmt->execute();
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		foreach( $row as $value ){
			if( $type == 'tab' ){
				$result[$value['pr_tab_id']]['name'] = $value['pr_tab_name'];
				if( !isset($result[$value['pr_tab_id']]['item'][$value['pr_id']]) ){
					$result[$value['pr_tab_id']]['item'][$value['pr_id']] = $value;
				}
				if( $value['pr_multiple'] != '0' && isset($result[$value['pr_tab_id']]['item'][$value['pr_id']]['pr_value']) ){
					if( !is_array($result[$value['pr_tab_id']]['item'][$value['pr_id']]['pr_value']) )
						unset($result[$value['pr_tab_id']]['item'][$value['pr_id']]['pr_value']);
					if( $value['pr_type'] == '3' || $value['pr_type'] == '4' ){
						$result[$value['pr_tab_id']]['item'][$value['pr_id']]['pr_value'][$value['pr_value']] = $value['pr_value'];
					}else{
						$result[$value['pr_tab_id']]['item'][$value['pr_id']]['pr_value'][] = $value['pr_value'];
					}
				}
				if( $value['pr_value_value'] != '' ){
					$result[$value['pr_tab_id']]['item'][$value['pr_id']]['items'][$value['pr_value_id']] = $value['pr_value_value'];
				}
			}else{
				$result['name'] = $value['pr_tab_name'];
				if( !isset($result['item'][$value['pr_id']]) ){
					$result['item'][$value['pr_id']] = $value;
				}
				if( $value['pr_multiple'] != '0' && isset($result['item'][$value['pr_id']]['pr_value']) ){
					if( !is_array($result['item'][$value['pr_id']]['pr_value']) )
						unset($result['item'][$value['pr_id']]['pr_value']);
					if( $value['pr_type'] == '3' || $value['pr_type'] == '4' ){
						$result['item'][$value['pr_id']]['pr_value'][$value['pr_value']] = $value['pr_value'];
					}else{
						$result['item'][$value['pr_id']]['pr_value'][] = $value['pr_value'];
					}
				}
				if( $value['pr_value_value'] != '' ){
					$result['item'][$value['pr_id']]['items'][$value['pr_value_id']] = $value['pr_value_value'];
				}
			}
		}
		
		
		return $result;
	}
	
	public static function addElement() {
		$arr = $_POST['form'];
		$ODBH[$arr['teh_content_id']] = core::other_connectDB($arr['teh_content_id']);
		
		$pr_name = $arr['pr_name'] ?? null;
		$pr_code = $arr['pr_code'] ?? null;
		$pr_section = $arr['pr_section'] ?? 0;
		// $pr_parent_id = $arr['pr_parent_id'] ?? 0;
		$pr_sort = $arr['pr_sort'] ?? null;
		$pr_action = $arr['pr_action'] ?? 0;
		
		if( !preg_match('/^[a-zA-Z0-9_-]+$/', $pr_code) ){
			return 'error';
		}
		
		if ($pr_name === null || $pr_code === null ) {
			// $error = 'Не заполнены обязательные поля';
			// return '/content/?content='.$arr['teh_content_id'].'&error='.urlencode($error);
			return 'error';
		} 
		
 		try {
			$sql = "INSERT INTO `pr_element` 
						(`pr_name`, `pr_code`, `pr_sort`, `pr_action`) 
					VALUES 
						(:pr_name, :pr_code, :pr_sort, :pr_action)";
			$stmt = $ODBH[$arr['teh_content_id']]->prepare($sql); 
			$stmt->execute([
				':pr_name' => $pr_name,
				':pr_code' => $pr_code,
				':pr_sort' => $pr_sort,
				':pr_action' => $pr_action,
			]);
			$newId = $ODBH[$arr['teh_content_id']]->lastInsertId();
			
			$sql = "INSERT INTO `pr_section_to` (`pr_section`, `pr_element`) VALUES (:pr_section, :pr_id)";
			$stmt = $ODBH[$arr['teh_content_id']]->prepare($sql); 
			$stmt->execute([':pr_id' => $newId,':pr_section' => $pr_section]);
			
			
			$ODBH[$arr['teh_content_id']]->beginTransaction();
			$stmt = $ODBH[$arr['teh_content_id']]->prepare("INSERT INTO `pr_element_value`(`pr_element_id`, `pr_property_id`, `pr_value`) VALUES (?, ?, ?)");
			$data = [];
			foreach( $arr['prop'] as $code => $value ){
				$values = is_array($value) ? $value : [$value];
				foreach( $values as $v ) {
					if( isset($v) && $v != '' )
						$stmt->execute([$newId, $code, $v]);
				}
			}
			$ODBH[$arr['teh_content_id']]->commit();
			
			$res['type'] = 'redirect';
			$res['url'] = '/content/element.php?content='.$arr['teh_content_id'].'&id='.$newId;;
			
			return $res;
		} catch (PDOException $e) {
			$ODBH[$arr['teh_content_id']]->rollBack();
			return "Ошибка при добавлении секции: " . $e->getMessage();
		}
	}
	
	public static function updateElement(){
		$arr = $_POST['form'];
		
		$pr_name = $arr['pr_name'] ?? null;
		$pr_code = $arr['pr_code'] ?? null;
		$pr_section = $arr['pr_section'] ?? 0;
		$pr_sort = $arr['pr_sort'] ?? null;
		$pr_action = $arr['pr_action'] ?? 0;
		
		$ODBH[$arr['teh_content_id']] = core::other_connectDB($arr['teh_content_id']);

		$newData = $_POST['form']['prop'];
		$oldData = $_POST['oldform']['prop'];
		$elementId = $_POST['form']['id'];
		
		
		$sql = "UPDATE pr_element SET 
					pr_name = :pr_name, pr_code = :pr_code,	pr_sort = :pr_sort, 
					pr_action = :pr_action WHERE pr_id = :pr_id";
		$stmt = $ODBH[$arr['teh_content_id']]->prepare($sql); 
		$stmt->execute([
			':pr_id' => $elementId,
			':pr_name' => $pr_name,
			':pr_code' => $pr_code,
			':pr_sort' => $pr_sort,
			':pr_action' => $pr_action,
		]);
		
		$sql = "UPDATE pr_section_to SET pr_section = :pr_section WHERE pr_element = :pr_id";
		$stmt = $ODBH[$arr['teh_content_id']]->prepare($sql); 
		$stmt->execute([':pr_id' => $elementId,':pr_section' => $pr_section]);
		
		$ODBH[$arr['teh_content_id']]->beginTransaction();
		
		foreach($newData as $propertyId => $newValues) {
			$oldValues = isset($oldData[$propertyId]) ? $oldData[$propertyId] : []; // значения по умолчанию
			if (is_array($newValues)) {
				$valuesToAdd = array_diff($newValues, $oldValues);
				$valuesToDelete = array_diff($oldValues, $newValues);
	
				foreach ($valuesToDelete as $valueToDelete) {
				  $stmt = $ODBH[$arr['teh_content_id']]->prepare("DELETE FROM pr_element_value WHERE pr_element_id = :element_id AND pr_property_id = :property_id AND pr_value = :value");
				  $stmt->execute([':element_id' => $elementId, ':property_id' => $propertyId, ':value' => $valueToDelete]);
				}
				
				foreach ($valuesToAdd as $valueToAdd) {
				  $stmt = $ODBH[$arr['teh_content_id']]->prepare("INSERT INTO pr_element_value (pr_element_id, pr_property_id, pr_value) VALUES (:element_id, :property_id, :value)");
				  $stmt->execute([':element_id' => $elementId, ':property_id' => $propertyId, ':value' => $valueToAdd]);
				}	
			}else{
				if( isset($oldData[$propertyId]) && $oldData[$propertyId] != '' && $newValues != '' && $newValues != $oldData[$propertyId] ){
					$updateStmt = $ODBH[$arr['teh_content_id']]->prepare("UPDATE pr_element_value SET pr_value = :value WHERE pr_element_id = :element_id AND pr_property_id = :property_id");
					$updateStmt->execute([':element_id' => $elementId, ':property_id' => $propertyId, ':value' => $newValues]);
				}elseif( isset($oldData[$propertyId]) && $newValues == '' ){
					$deleteStmt = $ODBH[$arr['teh_content_id']]->prepare("DELETE FROM `pr_element_value` WHERE pr_element_id = :element_id AND pr_property_id = :property_id");
					$deleteStmt->execute([':element_id' => $elementId, ':property_id' => $propertyId]);
				}elseif( $oldData[$propertyId] == '' && $newValues != '' ){
					$insertStmt = $ODBH[$arr['teh_content_id']]->prepare("INSERT INTO pr_element_value (pr_element_id, pr_property_id, pr_value) VALUES (:element_id, :property_id, :value)");
					$insertStmt->execute([':element_id' => $elementId, ':property_id' => $propertyId, ':value' => $newValues]);
				}
			}
		}
		
		foreach ($oldData as $propertyId => $oldValues) {
			if (!array_key_exists($propertyId, $newData)) {
				$deleteStmt = $ODBH[$arr['teh_content_id']]->prepare("DELETE FROM pr_element_value WHERE pr_element_id = :element_id AND pr_property_id = :property_id");
				$deleteStmt->execute([':element_id' => $elementId, ':property_id' => $propertyId]);
			}
		}
		
		$ODBH[$arr['teh_content_id']]->commit();
		
		$res['type'] = 'redirect';
		$res['url'] = '/content/element.php?content='.$arr['teh_content_id'].'&id='.$elementId;
		return $res;
	}


	// ПРОВЕРКА НАЗВАНИЯ СТАТЬИ
	public static function checkAddressName($title, $minLen = 1, $maxLen = 100, $exceptionChar = '_') {
		// Проверка длины строки
		if( strlen($title) < $minLen || strlen($title) > $maxLen ){
			return false;
		}
	
		// Проверка на пробелы
		if( strpos($title, ' ') !== false ){
			return false;
		}
	
		// Проверка на нижний регистр и спецсимволы(игнорируя разделитель)
		if( !preg_match("/^[a-z0-9" . preg_quote($exceptionChar, '/') . "]+$/", $title) ) {
			return false;
		}
	
		return true;
	}
	
	
	
	
	
	
	
	
	//вывод полей свойств
/* 	public static function buildProperty($admId, $type, $id = null) {
		$html = '';
		
		$arr = core::getContentById($admId, true);
		$ODBH[$admId] = core::other_connectDB($admId, $arr);
		if (!$ODBH[$admId]) {
			return false;
		}
		
		if( $id ){
			if( $type == 'section' ){
				$arrProp = self::getSectionDeatil($admId, $id);
			}elseif( $type == 'element' ){
				
			}
		}else{
			
		}
		
		if( $type == 'section' ){
			foreach( $arrProp['property'] as $code=>$value ){
				$html .= "{$value['pr_name']}: <br/><input type=\"text\" name=\"{$value['pr_id']}\" value=\"{$value['pr_value']}\"/><br/><br/>";
			}
		}
		

		// foreach ($tree as $item) {
			// $prefix = str_repeat('- ', $level);
			// $options .= "<option value=\"{$item['pr_id']}\">{$prefix}{$item['pr_name']}</option>";
			// if( isset($item['items']) && is_array($item['items']) ){
				// $options .= self::buildTreeOptions($item['items'], $level + 1);
			// }
		// }
		return $html;
	} */

	//формирование левое меню КОНТЕНТ
	public static function printTreeSection($data, $contentUrl = '') {
		$html = '';

		foreach( $data as $item ) {
			if( !empty($item['url']) ) {
				// Только верхние разделы
				$contentUrl = $item['url'];

				$html .= '<div class="adm-tree-item">';
				$html .= '<div class="adm-tree-item-title" onclick="toggleTreeItem(event)">' . $item['name'] . '</div>';
				$html .= '<div class="adm-tree-item-children">';

				$html .= '<div class="adm-tree-item">';
				$html .= '<div class="adm-tree-item-title" onclick="toggleTreeItem(event)"><a href="' . $contentUrl . '">Разделы</a></div>';

				$html .= '<div class="adm-tree-item-children">';
				$html .= SELF::printTreeSection($item['items'], $contentUrl);
				$html .= '</div></div></div></div>';
			} else if( !empty($item['items']) ) {
				// Подразделы
				$html .= '<div class="adm-tree-item">';
				$html .= '<div class="adm-tree-item-title" onclick="toggleTreeItem(event)">';
				$html .= '<svg width="20px" height="20px" viewBox="0 0 100 100"><path style="fill:#CCCCCC;stroke:#222222;stroke-width:2" d="M 4,88 C 4,87 3.6,25 3.6,25 3.6,25 3,20 8,20 c -1,0 6,0 6,0 l 0,-6 c 0,0 0,-3 3,-3 l 17,0 c 0,0 3,0 3,3 l 0,6 43,0 c 0,0 4,0 4,4 l -2,64 z"/><path style="fill:#EDEDED;stroke:#222222;stroke-width:2;fill-opacity:0.8" d="M 4,88 15,40 c 0,0 0,-7 8,-7 10,0 66,0 66,0 0,0 9,-1 7,6 -2,7 -12,49 -12,49 z"/></svg>';
				$html .= '<a class="ms-2" href="'. $contentUrl . $item['pr_id'] .'">' . $item['pr_name'] . '</a></div>';

				$html .= '<div class="adm-tree-item-children">';
				$html .= SELF::printTreeSection($item['items'], $contentUrl);
				$html .= '</div></div>';
			} else {
				// Просто ссылки
				$html .= '<div class="adm-tree-link">';
				$html .= '<svg width="20px" height="20px" viewBox="0 0 100 100"><path style="fill:#CCCCCC;stroke:#222222;stroke-width:2" d="M 4,88 C 4,87 3.6,25 3.6,25 3.6,25 3,20 8,20 c -1,0 6,0 6,0 l 0,-6 c 0,0 0,-3 3,-3 l 17,0 c 0,0 3,0 3,3 l 0,6 43,0 c 0,0 4,0 4,4 l -2,64 z"/><path style="fill:#EDEDED;stroke:#222222;stroke-width:2;fill-opacity:0.8" d="M 4,88 15,40 c 0,0 0,-7 8,-7 10,0 66,0 66,0 0,0 9,-1 7,6 -2,7 -12,49 -12,49 z"/></svg>';
				$html .= '<a href="'. $contentUrl . $item['pr_id'] .'" class="ms-2">' . $item['pr_name'] . '</a>';
				$html .= '</div>';
			}
		}


		return $html;
	}
	
	//формирование полей для КОНТЕНТ
	public static function printFormElement($arr){
		// $title, $type, $name, $value = null, $multi = 0
		$id = $arr['pr_id'];
		$title = $arr['pr_name'];
		$type = $arr['pr_type'];
		$value = $arr['pr_value']??null;
		$multi = $arr['pr_multiple'];
		$name = 'form[prop]['.$arr['pr_id'].']';
		$items = $arr['items']??null;
		
		$html = '';
		if( $type == '1' ){ //text
			$html .= '<tr><td class="adm-detail-content-cell-l">'.$title.':</td><td>';
			$html .= '<input type="text" name="'.$name.'" value="'.$value.'" />';
			$html .= '<input class="adm-detail-content-oldInput" type="text" name="old'.$name.'" value="'.$value.'"  readonly/>';
			$html .= '</td></tr>'; 
			
		}elseif( $type == '2' ){ //textarea
			$html .= '<tr class="adm-detail-content-tittle"><td class="adm-detail-content-cell-l">'.$title.':</td><td></td></tr>';
			$html .= '<tr class="adm-detail-content-text-area"><td colspan="2">';
			$html .= text_editor::spawnTextEditor($name, $value);
			$html .= '<textarea class="adm-detail-content-oldInput" name="old'.$name.'" readonly>'.$value.'</textarea>';
			$html .= '</td></tr>';
		}elseif( $type == '3' ){ //checkbox
			$html .= '<tr class="adm-detail-content-checkbox"><td class="adm-detail-content-cell-l">'.$title.':</td><td>';
			if( $multi == 0 ){
				$checked = ($value == 1) ? 'checked' : '';
				$html .= '<input type="checkbox" value="1" name="'.$name.'" '. $checked .' />';
				$html .= '<input class="adm-detail-content-oldInput" value="1" type="checkbox" name="old'.$name.'" '. $checked .' />';
			}else{
				foreach( $items as $c=>$v ){
					$checked = ( isset($value) && in_array($c,$value) ) ? 'checked' : '';
					$html .= '<label><input type="checkbox" value="'.$c.'" name="'.$name.'['.$c.']" '. $checked .' />'.$v.'</label>';
				}
				foreach( $items as $c=>$v ){
					$checked = ( isset($value) && in_array($c,$value) ) ? 'checked' : '';
					$html .= '<label class="adm-detail-content-oldLabel"><input class="adm-detail-content-oldInput" value="'.$c.'" type="checkbox" name="old'.$name.'['.$c.']" '. $checked .' />'.$v.'</label>';
				}
			}
			$html .= '</td></tr>'; 
		}elseif( $type == '4' ){ //select
			$html .= '<tr><td class="adm-detail-content-cell-l">'.$title.'</td><td>';
			$html .= '<select name="'.$name.'" >';
			//
			$html .= '</select>';
			$html .= '</td></tr>'; 
		}elseif( $type == '5' ){ //select size
		
			
		}
		return $html;
	}







	public static function test(){
		return 'GO51'; 
	}
}
?>