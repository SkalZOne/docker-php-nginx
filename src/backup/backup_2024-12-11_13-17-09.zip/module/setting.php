<?
namespace classes;

use PDO;

/**/

class setting{
	
	public static function getAllConnect(){
		
	}
// $arr = self::getContentById($admId, true);




	public static function test(){
		return 'GO51'; 
	}
}
?>