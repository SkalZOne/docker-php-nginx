<?
namespace classes;

use PDO;

class media{
	


	public static function addMediaFile(){
		$DBH = core::connectDB();
		$mime = core::getMIME('media', 'module');
        $uploadedFiles = $_FILES['uploaded_file'];
		$arr = core::getFTP(1, 'type');  
		$post = $_POST;
		$imgServerUrl = server::getServer(1,'type')['0']['adm_url'];
		$imgCashData = self::getAllMedia();
		$ftp = [];
		$sql = "INSERT INTO `adm_media` (`adm_src`, `adm_section`, `adm_description`) VALUES (:src, :section, :description)";
		$createdFolders = [];

		foreach( $arr as $code=>$value ){
			$ftp[$code] = core::connectFTP($code, $arr);  
		}
		
        $result = [];

        foreach ($uploadedFiles['name'] as $key => $name) {
			if( $name == '' ){continue;}
            $mimeType = $uploadedFiles['type'][$key];
            $tmp_name = $uploadedFiles['tmp_name'][$key];

			if( !isset($mime[$mimeType]) || $mime[$mimeType]['adm_allowed'] != 1 ){
                $result[$key] = ['error' => "Ошибка: недопустимый MIME-тип файла: " . $mimeType, 'file' => $name];
                continue;
            }

            //Проверка реального типа файла
            $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
            $realMimeType = finfo_file($fileInfo, $tmp_name);
            finfo_close($fileInfo);

            if ($mimeType !== $realMimeType) {
                $result[$key] = ['error' => "Ошибка: MIME-тип не соответствует реальному типу файла.", 'file' => $name];
                continue;
            }

            //Проверка размера файла (опционально)       
			$maxSize = 10 * 1024 * 1024; // 10 МБ (пример)
            if ($uploadedFiles['size'][$key] > $maxSize) {
                $result[$key] = ['error' => "Ошибка: размер файла превышает допустимый.", 'file' => $name];
                continue;
            } 

            //Если все проверки пройдены
			$stmt = $DBH->prepare("SELECT MAX(adm_id) AS id FROM adm_media");
			$stmt->execute();
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$nextId = isset($row['id']) ? $row['id'] : 0;
			$path = '/media/' . core::encode_number_crc32(intdiv($nextId, 500)) . '/';
			$uniqueName = $path . uniqid() . '.' . $mime[$mimeType]['adm_extension'];

 			if(!isset($createdFolders[$path])) {
				foreach ($ftp as $valFtp) {
					$list = ftp_nlist($valFtp, $path);
					// if( !ftp_chdir($valFtp, $path) ){
					if( $list === FALSE || empty($list) ){
						ftp_mkdir($valFtp, $path);
					}
				}
				$createdFolders[$path] = true; // Помечаем папку как созданную
			}
			
			foreach( $ftp as $valFtp ){
				if( ftp_put($valFtp, $uniqueName, $tmp_name, FTP_BINARY) ){
					$stmt = $DBH->prepare($sql);
					$stmt->execute([
						':src' => $uniqueName,
						':section' => $post['section'],
						':description' => $post['name'][$key],
					]);
					$result[$key] = ['success' => true, 'name' => $name, 'new_name' => $uniqueName];
				} else {
					$result[$key] = ['errir' => 'Не удалось загрузить на сервер.', 'file' => $name];
				}
			}

			// Обновление данных кэш файла(конкретнее процессы в createImageCash)
			$arrKeyLast = array_key_last($imgCashData[$post['section']]['item']);
			$itemsCount = count($imgCashData[$post['section']]['item'][$arrKeyLast]);
			$page = ( $itemsCount < 20 ) ? $arrKeyLast : $arrKeyLast + 1;

			$newItem = [];
			$newItem['adm_id'] = $DBH->lastInsertId();
			$newItem['adm_src'] = $imgServerUrl . $uniqueName;
			$newItem['adm_description'] = $post['name'][$key];

			$imgCashData[$post['section']]['item'][$page][] = $newItem;
        }

		// Обновление кэш файла
		$cacheFileDir = $_SERVER['DOCUMENT_ROOT'] . '/cache/media/filelist.php';
		file_put_contents($cacheFileDir, '<?php return ' . var_export($imgCashData, true) . ';');
		
		foreach ($ftp as $valFtp) {
			ftp_close($valFtp);
		}

        return $result;
	} 
	
	
	public static function getSection(){
		$DBH = core::connectDB();
		$stmt = $DBH->prepare("SELECT * FROM `adm_media_section`");
		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
	
	
	public static function getAllMedia(){
		$cacheFileDir = $_SERVER['DOCUMENT_ROOT'] . '/cache/media/filelist.php';

		if( !file_exists($cacheFileDir) ){
			self::createImageCash();
		}

		$data = include $cacheFileDir;

		return $data;
	}

	public static function createImageCash() {
		$DBH = core::connectDB();
		$url = server::getServer(1,'type')['0']['adm_url'];

		if (!$DBH) {
			return false;
		}
		$stmt = $DBH->prepare("SELECT 
									adm_media.*,
									adm_media_section.adm_id AS adm_section_id,
									adm_media_section.adm_name AS adm_section_name
								FROM adm_media	
								LEFT JOIN adm_media_section ON adm_media.adm_section = adm_media_section.adm_id");
		$stmt->execute();
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);

		// формирование $result для адекватной реализации пагинации
		foreach( $row as $item ) {
			$result[$item['adm_section_id']]['name'] = $item['adm_section_name'];
			$result[$item['adm_section_id']]['item'] = array(1 => array());
		}

		foreach( $row as $item ){
			$arrKeyLast = array_key_last($result[$item['adm_section_id']]['item']);  // Получение последней страницы пагинации
			$itemsCount = count($result[$item['adm_section_id']]['item'][$arrKeyLast]);  // Кол-во элементов на этой странице
			$page = ( $itemsCount < 20 ) ? $arrKeyLast : $arrKeyLast + 1;  // если больше их 20, новая страница

			$result[$item['adm_section_id']]['name'] = $item['adm_section_name'];
			
			$formattedItem['adm_id'] = $item['adm_id'];
			$formattedItem['adm_src'] = $url.$item['adm_src'];
			$formattedItem['adm_description'] = $item['adm_description'];

			$result[$item['adm_section_id']]['item'][$page][] = $formattedItem;
		}
		
		// Создание и запись данных в файл
		$cacheFileDir = $_SERVER['DOCUMENT_ROOT'] . '/cache/media/filelist.php';
		file_put_contents($cacheFileDir, '<?php return ' . var_export($result, true) . ';');
	}
	
	public static function test(){
		return 'GO51'; 
	}
}
?>